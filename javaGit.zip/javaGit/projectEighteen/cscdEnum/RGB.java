package cscdEnum;
import java.util.*;

public enum RGB {
 RED("RED",255,0,0),GREEN("Green",0,255,0),BLACK("BLACK",0,0,0);
	private String name;
	private int r,g,b;
	private RGB(final String name, final int r, final int g, final int b)
	{
		this.name=name;
		this.r=g;
		this.g=g;
		this.b=b;
	}
	public String getName()
	{
		return this.getName();
	}
	public String toString()
	{
		String res=this.name();
		String b=res.substring(1).toLowerCase();
		String Final=res.charAt(0)+b;
		return Final;
	}
	
	

}


