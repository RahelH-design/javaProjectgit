package cscdEnum;


public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RGB acolor;
		acolor=RGB.GREEN;
		System.out.println(acolor.name());
		//System.out.println(acolor.getName());
		RGB[] array=new RGB[6];
		array[0]=RGB.GREEN;
		array[1]=RGB.BLACK;
		array[2]=RGB.RED;
		for (RGB a:array)
		{
			System.out.println(a.name());
		}

	}

}
