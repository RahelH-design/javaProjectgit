package cscd210Lab5s; // create package
import java.util.Scanner; //import scanner class 

//create a class name called CSCD210Lab5Strings
public class CSCD210Lab5Strings {

	//main method
	public static void main(String[] args) 
	{
		//create  a new scanner with specified input stream
		   Scanner kb= new Scanner(System.in);
		   
		   //declare string variable fruit1, fruit2, fruit3
	        String fruit1, fruit2, fruit3;
	        
	        //declare the output string is assigned to empty string literal
	        String output="";
	        
	        //output the prompt
	        System.out.print("enter your first fruit:");
	        
	        //wait the user to enter the line of text
	        fruit1=kb.nextLine();
	        
	        //output the prompt
	        System.out.print("enter your first fruit:");
	        
	        //wait the user to enter the line of text
	        fruit2=kb.nextLine();
	        
	        //output the prompt
	        System.out.print("enter your first fruit:");
	        
	        //wait the user to enter the line of text
	        fruit3=kb.nextLine();
	        
	        //the user input change to lower case
	        fruit1=fruit1.toLowerCase();
	        fruit2=fruit2.toLowerCase();
	        fruit3=fruit3.toLowerCase();
	        
	        //compare 
	        //this would return zero compare the unicode value of their each character
	         
	        if(fruit1.compareTo(fruit2)<=0 && fruit1.compareTo(fruit3)<=0)
	        {   //print fruit1
	        	
	            
	            //compare if fruit2 >fruit1 less than 0
	            if(fruit2.compareTo(fruit3) <=0) 
	            {
	                //fruit 2 next
	                output+= fruit1 + ", " + fruit2 + ", " + fruit3;
	                
	            } else {
	            	
	                //fruit 3 next
	                output+= fruit1 +", "+fruit3+ ", " +fruit2;
	            }
	            
	            
	        }
	        
	        //compare fruit2
	        else if(fruit2.compareTo(fruit1) <=0 && fruit2.compareTo(fruit3) <=0) 
	        
	        {    
	            if(fruit3.compareTo(fruit1)<=0)
	            {
	            	
	            	//fruit 3
	                output+= fruit2 +", "+fruit3 + ", " +fruit1;
	            }
	            
	            
	            else
	            {   //fruit 1
	                output+= fruit2 + ", "+fruit1 + ", " + fruit3;
	            }
	           
	        }
	        
	        //compare fruit3
	        else if(fruit3.compareTo(fruit1)<=0 && fruit3.compareTo(fruit2)<=0)
	        {
	        	//compare fruit2
	            if(fruit2.compareTo(fruit1)<=0)
	            {
	                //fruit 2
	            	output+= fruit3 + ", " +fruit2 + ", " +fruit1;
	            }
	            else
	            {
	            	//fruit 1
	                output+= fruit3 + ", "+fruit1 + ", " + fruit2;
	            }
	        }
	        
	        //the out put in ascending order 
	        System.out.println("The fruit in ascending order"+" "+ output);
			

	 }//ending the method

}//ending the class
