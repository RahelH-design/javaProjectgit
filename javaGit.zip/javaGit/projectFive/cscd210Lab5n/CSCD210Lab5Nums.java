package cscd210Lab5n;
import java.util.Scanner;

public class CSCD210Lab5Nums {

	public static void main(String[] args) {
		
		int num1, num2, num3, temp;
		Scanner keyboard= new Scanner(System.in);
		
		System.out.print("Enter first integer: ");
		num1=keyboard.nextInt();
		System.out.print("Enter second integer: ");
		num2= keyboard.nextInt();
		System.out.print("Enter third integer: ");
		num3=keyboard.nextInt();
		if (num1<num2)
		
		//sort num1 and num2
		if(num1>num2)
		{
			//num1 assigned to temporary variable
		    temp=num1;
		    //num2 assigned to num1(swap num2 to num1)
		    num1=num2;
		    //temp assigned to num2
		    num2=temp;
		}
		//sort num2 and num3
		if(num2>num3)
		{
			//num2 assigned to temporary variable
			temp=num2;
			//num3 assigned to num2(swap num3 to num2)
		    num2=num3;
		    //temporary value assigned to num3
		    num3=temp;
		}
		//sort num1 and num3 again
		if(num1>num2)
		{
			//num1 assigned to temporary variable
			temp=num1;
			//num3 assigned to num2(swap num2 to num1)
			num1=num2;
			//temporary value assigned to num2
			num2=temp;
		}
		//System.out.print(temp);
		System.out.println("The number in ascending order "+num1+","+" "+num2+","+" "+"and" +" "+num3);

	}

}
