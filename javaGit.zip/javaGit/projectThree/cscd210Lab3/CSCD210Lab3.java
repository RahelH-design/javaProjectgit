package cscd210Lab3;
import java.util.Scanner;
import java.text.DecimalFormat;

public class CSCD210Lab3 {

	public static void main(String[] args) {
		
	//declare an empty string reference
	  String name=null;	
		
	 //declare a decimal format reference named
     DecimalFormat fmt= new DecimalFormat("0.00");
     
     //declare a double primitive named finish time
     double finishTime;
     
     //declare the distance
     double distance_Km=2.5;
     
     
     //declare a scanner reference named kb and assign kb to a scanner object
     Scanner kb=new Scanner(System.in);
     
   
     
     //prompt the user for the finish time
     System.out.print("please enter the finish time: ");
     
     //read the finish time converts input given as string to double value 
     finishTime=kb.nextDouble();
     kb.nextLine();
     //finishTime =Double.parseDouble(kb.nextLine());
     
     //prompt for the skier name
     System.out.print("please enter the skier name: ");
     
     //read the name 
     name  =kb.nextLine();
     
     //conversion 
     double meterPerSecond= (distance_Km*Math.pow(10, 3))/finishTime;
     double feetPerSecond = (meterPerSecond*3.281);
     double kiloMeterPerHour=feetPerSecond/0.911;
     double milePerHour= kiloMeterPerHour *0.621;
     double second= (1.60934 *finishTime)/(distance_Km);
     int minute= (int) ((second)/60);
     double seconds = (0.09144 *finishTime)/(distance_Km);
     
     System.out.println();
     //display the output
     System.out.println("The" +" " +name+" " +" was traveling at a rate of:");
     System.out.println(fmt.format(meterPerSecond) +" "+ "meters per second,"); 
     System.out.println(fmt.format(feetPerSecond)+ " "+"feet per second,");
     System.out.println(fmt.format(kiloMeterPerHour)+ " "+"kilometer per hour,");
     System.out.println(fmt.format(milePerHour)+ " "+"mile per hour,");
     
     System.out.println();
     System.out.println("It would take" +" " + minute+" " +"minute" +" "+"and" +" " +fmt.format(second) + " "+ "seconds"+ " " + "for the Sally to ski one mile.");
     System.out.println("It would take"+" "+fmt.format(seconds)+ " "+"seconds for the Sally to ski 100 yards.");
                    
     
		
     
     
     
	}

}
