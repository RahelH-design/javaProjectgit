package cscd210Lab14Methods;

import java.util.Scanner;

import cscd210Classes.Author;

public class CSCD210Lab14Methods {

	/*
	 * The menu method gives the user 3 options 
			1) Print the array 
			2) Add a author to the array and sort 
			3) Quit 
		Parameters:
			kb - Representing the open Scanner Object
		Returns:
			int representing the menu choice
		Throws:
			java.lang.IllegalArgumentException - if the Scanner is null
		NOTE:
		You will clean the input buffer and you will guarantee range
	 */
	public static int menu(final Scanner kb) {

		if (kb == null) 
		      throw new IllegalArgumentException("Scanner can not be null"); // in case scanner is null
		
		int menuChoice = 0;
		
		while (menuChoice < 1 || menuChoice > 3) 
		{
			System.out.println("Menu Choices \n" +
					"			1) Print the array \r\n" + 
					"			2) Add a author to the array and sort \r\n" + 
					"			3) Quit");
			
			menuChoice = kb.nextInt();
		}
		
		kb.nextLine(); // clean the buffer
		return menuChoice;
	}	
	
	/*
	 * The fillArray method is passed a created array. 
	 * The method reads a line from the file and then breaks that line into 
	 * first name, last name, and publisher. The method will create an author 
	 * object and insert it into the array
		Parameters:
			fin - Representing the open Scanner Object
			array - Representing the array of Author references
		Throws:
			java.lang.IllegalArgumentException - if the Scanner is null or the array is null or the array length is < 1
		NOTE:
			You will clean the input buffer
	 */
	public static void fillArray(final Scanner fin, final Author[] array) {
		
		if (fin == null ) 
		      throw new IllegalArgumentException("Scanner can not be null"); // in case scanner is null
		
		if (array == null || array.length < 1) 
		      throw new IllegalArgumentException("Array can not be null or empty"); // in case scanner is null
		
		String line = "";
		String firstName = "";
		String lastName = "";
		String publisher = "";
		
		for (int i = 0; i < array.length; i++) {
			line = fin.nextLine();
			
			firstName = line.split(",")[0].split(" ")[0];
			lastName = line.split(",")[0].split(" ")[1];
			publisher = line.split(",")[1].trim();
			
			array[i] = new Author(firstName, lastName, publisher);
		}
	}

	/*
	 * The add method creates a copy of the array passed in. Each reference in the original array is copied into the new array
		The user is prompted for first name, last name, and publisher. 
		A new author object is created and that object is placed into the array.
		Parameters:
			array - Representing the array of Author references
			kb - Representing the open Scanner Object
		Returns:
			the new array with the new author
		Throws:
			java.lang.IllegalArgumentException - if the Scanner is null or the array is null or the array length is < 1
		NOTE:
		You will clean the input buffer
	 */
	public static Author[] add(final Author[] array, final Scanner kb) {
		
		int i;
		
		Author[] newArray = new Author[array.length + 1];
		
		if (kb == null ) 
		      throw new IllegalArgumentException("Scanner can not be null"); // in case scanner is null
		
		if (array == null || array.length < 1) 
		      throw new IllegalArgumentException("Array can not be null or empty"); // in case scanner is null
		
		for (i = 0; i < array.length; i++) {
			newArray[i] = new Author(array[i].getFirst(), array[i].getLast(), array[i].getPublisher());
		}
		
		String firstName = "";
		String lastName = "";
		String publisher = "";
		
		System.out.println("Please enter first name");
		firstName = kb.nextLine();
		
		System.out.println("Please enter first last name");
		lastName = kb.nextLine();
		
		System.out.println("Please enter first publisher");
		publisher = kb.nextLine();
		
		newArray[i] = new Author(firstName, lastName, publisher);
		
		return newArray;
	}

}

