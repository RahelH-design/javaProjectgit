package cscd210Classes;

public class Author implements Comparable<Author>{
	
	private String first; // The first name of the author
	private String last; // The last name of the author
	private String publisher; // The publisher name
	
	/* The only constructor used to create an Author object 
	 	Parameters:
			first - The String representing the first name
			last - The String representing the last name
			publisher - The String representing the publisher
		Throws:
			java.lang.IllegalArgumentException - if any of the Strings are null or empty
	*/
	public Author(final String first, final String last, final String publisher) {
		
		if (first == null || last == null || publisher == null || first.isEmpty() || last.isEmpty() || publisher.isEmpty())
			throw new IllegalArgumentException("Strings can not be empty!");
			
		this.first = first;
		this.last = last;
		this.publisher = publisher;
	}

	
	/*
		The method getLast returns the last name of the Author
		Returns:
			String representing this last name
	 */
	public String getLast() {
		return last;
	}
	
	public String getFirst() {
		return first;
	}

	public String getPublisher() {
		return publisher;
	}

	/*
	 * Returns:
			String this first name plus space plus this last name plus space dash space plus this publisher
	 */
	@Override
	public String toString() {
		return this.first + " " + this.last + " - " + this.publisher;
	}
	
	/*
  		The compare to method guarnateed via the generic the parameter will be an Author object
		Specified by:
			compareTo in interface java.lang.Comparable<Author>
		Parameters:
			another - Representing the Author object to be compared
		Returns:
			int Representing order. 
		Two author objects are compared based on the last name. 
		If the last names are the same then compares by first name. 
		If the last name and first name are the same then comparison based on the publisher
		Throws:
			java.lang.IllegalArgumentException - if another is null
		NOTE:
			This method must have @Override before the method header
	 */
	@Override
	public int compareTo (final Author another) {
		
		if (another == null)
			throw new IllegalArgumentException("another can not be null!");
		
		int compareValue = this.getLast().compareTo(another.getLast()); // returns 0 if equal, 1 if first is greater, 2 if second is greater
		
		if (compareValue == 0) { 
			compareValue = this.getFirst().compareTo(another.getFirst());
			if (compareValue == 0) { 
				compareValue = this.getPublisher().compareTo(another.getPublisher());
			}
		}
		
		return compareValue;
	}
}
