package cscd210Utils;

import java.io.PrintStream;

/*
The ArrayUtils class performs basic array functions, such as printing the arrays.
NOTE:
The class uses generics for the type. Please note the <T> on the class header
 */

public class ArrayUtils <T> {
	
	/*
	 *  The printArray prints the array in the format [item1, item2, ...]
		Type Parameters:
			T - Representing the Generic type of the array
		Parameters:
			myArray - Representing the actual array
			fout - Representing the PrintStream object
		Throws:
			java.lang.IllegalArgumentException - if the array is null, fout is null, or the array length is < 1
		NOTE:
			Please notice the method is <T> void for the return type and T for the array type. T is replaced by the actual type when the code is compiled.
	 */
	
	public static <T> void printArray(final T[] myArray, final PrintStream fout) {
		
		if (myArray == null || myArray.length < 1 || fout == null)
	         throw new IllegalArgumentException("Bad array params in printArray");
	      
		fout.print("[");
		
		for (int i = 0; i < myArray.length; i++) {
			if (i + 1 != myArray.length) fout.print(myArray[i] + ", ");
			else fout.print(myArray[i]);
		}
		
		fout.print("]");
		fout.println();
	}

}
