package cscd210Methods;

import java.io.PrintStream;
import java.util.Scanner;


public class CSCD210Lab9Methods 
{
	///declare the method fill Array with two parameter
    public static String[] fillArray(final Scanner fin, final int total) 
    {
    	//reference variable line point to the total 
        String [] line = new String[total];
        //initialize i 
        int i = 0;
        
        while (fin.hasNextLine()){
            line[i] = fin.nextLine();
            i++;
        }
        //return line
        return line;
    }

    public static void printArray(final String[] words,final PrintStream out) 
    {
        for (String line:words) 
        {   //print the line 
            out.println(line);
        }
    }
}
