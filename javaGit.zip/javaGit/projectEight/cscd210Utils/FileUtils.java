package cscd210Utils;
import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileUtils 

{
   //declare the openInputFile method with one parameter
    public static File openInputFile(final  Scanner kb)
    {
    	//prompt the user to enter the file name
        System.out.println("Enter the filename");
        
        //using the while loop and the condition is true
        while (true)
        {
         //file name assigned to read what the user enter
          String filename =   kb.nextLine();
          
          //file reference variable point at the object to filename
            File file = new File(filename);
            //file exists
            if(file.exists())
            {
            	//return file
               return file;
            }
            //it will print out the file to print out if it does not exist
            System.out.println("The Filename Doesnt exists!\n Try Again!");
        }
    }
    //decalre a method header called count record with two parameter
    public static int countRecords( final Scanner fin, final int i) 
    {
    	//initialize to zero
       int  num = 0;
       
       //
       while (fin.hasNextLine())
       {
           String m = fin.nextLine();
           num++;
       }
       //return the num
       return  num;
    }

    public static File openInputFile(final String s) throws FileNotFoundException {
        File file = null;

        file = new File(s);

        if (file.exists()){
            return  file;
        }else {
            throw  new FileNotFoundException();
        }
    }
}
