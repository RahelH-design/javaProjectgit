package cscd210Utils;
import java.io.*;

public class SortUtils
{

	//declare the method header called selection sort with one string array parameter
	public static void selectionSort(final Comparable[] words) 
	//public static void selectionSort(final String[] words) 
    {
    	//declare temp
        String temp;
        //was swap gets true
        boolean wasSwap = true;
        
        //to swap the letters using the for loop
        for (int i = 0; i < words.length - 1 && wasSwap; ++i) 
        {   //wasSwap gets false
            wasSwap = false;
            for (int x = 0; x < words.length - i - 1; ++x) 
            {
                if (words[x].compareTo(words[x+1]) > 0) 
                {
                    temp = (String) words[x];
                    words[x] = words[x+1];
                    words[x+1] = temp;
                    wasSwap = true;
                }
            }
        }//end the for loop
    }//end the method
}//end the class 
