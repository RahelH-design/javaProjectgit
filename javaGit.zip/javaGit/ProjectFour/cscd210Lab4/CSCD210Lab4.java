package cscd210Lab4;
import java.util.Scanner;


public class CSCD210Lab4 {

	public static void main(String[] args) {
		
		//declare constant 
		final String DEGREE  = "\u00b0";
		
		//declare primitive
		double length;
		double side;
		double area;
		
		//declare a scanner reference named kb and assign kb to a scanner object
		Scanner kb = new Scanner(System.in);
		
		//declare empty string
		String input = null;
		
		//prompt the user for the length
		System.out.print("Please enter the length from the center to the vertex");
		
		//read the input
		input=kb.nextLine();
		
		//read the length input using the scanner object
		length=Double.parseDouble(input);
		
		System.out.println("You entered a length of :"+ length);
		
		//calculation of side and area
		side= 2*length*Math.sin(((Math.PI/5)));
		area =(5*(Math.pow(side,2)))/(4*Math.tan(Math.PI/5));
		
		//display the calculation
		System.out.printf("PI/5 is: %.2f\n", (Math.PI/5));
		System.out.printf("The sin of the radian value of PI/5 is: %.2f\n", Math.sin(((Math.PI/5))));
		System.out.printf("The angle, in degrees, from the sin calculation is : %.2f%s\n",Math.toDegrees(Math.sin(Math.PI/5)),DEGREE);
		System.out.printf("The length of a side is: %.2f\n",side);
		System.out.printf("The area of the pentangon is: %.3f\n",area);
		
			

	}

}
