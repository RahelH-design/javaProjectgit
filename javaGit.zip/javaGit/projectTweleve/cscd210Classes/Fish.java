package cscd210Classes;

import com.sun.org.apache.bcel.internal.generic.INSTANCEOF;

/*
 * Fish - Class in cscd210Classes
	
	A fish class that has the standard methods and allows two fish to be compared by the 
	compareTo method.
 * 
 */

public class Fish implements Comparable<Fish> {

	/*
	 * Contains 2 Private data members
		o String type
		o double weight
	 */
	private String type; // private data member to hold the fish type
	private Double weight; // private data member to hold the fish weight
	
	
	/*
	 * getType() - Method in class cscd210Classes.Fish
		The getType method returns the fish type
	*/
	public String getType() {
		return this.type;
	}
	
	
	/*
	 * getWeight() - Method in class cscd210Classes.Fish
		The getWeight method returns the fish weight
	 */
	public double getWeight() {
		return this.weight;
	}
	
	
	/*
	 * setType(String) - Method in class cscd210Classes.Fish
		The setType sets the fish type only if the type is not null or empty
	 */
	public void setType(final String type) {
		if (type == null || type.trim().isEmpty()) throw new IllegalArgumentException("Please enter type of the fish properly");
		
		this.type = type;
	}
	
	/*
	 * setWeight(double) - Method in class cscd210Classes.Fish
		The setWeight sets the fish weight only if the weight is >0
	 */
	public void setWeight(final Double weight) {
		if (weight <= 0) throw new IllegalArgumentException("Weight must be greater than 0!");
		
		this.weight = weight;
	}
	
	
	/*
	 * Fish(String, double) - Constructor for class cscd210Classes.Fish
		Fish constructor that take the type and weight as parameters
		Parameters:
			type - Representing the fish type
			weight - Representing the fish weight
		Throws:
			java.lang.IllegalArgumentException - if the type is null or empty
			java.lang.IllegalArgumentException - if the weight is <=0
	 */
	public Fish(final String type, final Double weight) {
		if(type==null || type.isEmpty()) throw new IllegalArgumentException("type must not be null");
		if(weight<=0) throw new IllegalArgumentException("weight must be greater than zero");
		this.setType(type);
		this.setWeight(weight);
	}
	
	
	/*
	 * toString() - Method in class cscd210Classes.Fish
		The toString methods returns a String that is the type - weight
		Returns:
			String Representing type - weight (Example: trout - 1.234)
	 */
	@Override
	public String toString() {
		return type + " - " + weight;
	}
	
	
	/*
	 * equals(Object) - Method in class cscd210Classes.Fish
		The equals method 
		returns true if this == obj
		returns false if obj == null
		returns false if obj is not an instanceof Fish
		returns true if the this type is equal another type and this weight  is equal to another weight false otherwise
		Parameters:
			obj - Representing the object being passed in
		Returns:
			boolean - Representing if the this type is equal another type and this weight is equal to another weight
	 */
	@Override
	public boolean equals(final Object obj) {
		
		if (obj == null) return false;
		
		if (obj instanceof Fish) {
			if (this == obj) return true;
			if (this.weight.equals(((Fish)obj).weight) && this.type.equals(((Fish)obj).type)) return true; // casting so we can get weight and type from obj
		}
		
		return false;
	}
	
	
	/*
	 * hashCode() - Method in class cscd210Classes.Fish
		The hashCode method adds the int from calling the Strings hashCode for type and 
		the Double hashCode for weight
		Returns:
			int Representing the addition of the Strings hashCode for type and the Double hashCode for weight
	 */
	@Override
	public int hashCode() {
		return type.hashCode() + weight.hashCode();
	}

	
	/*
	 * compareTo � by type first and weight second 
	 * � must use <Fish> 
	 * � must have @Override
	 * Parameters:
		another - Representing the fish being passed in
	   Returns:
		int The value 0 if the argument another is equal to this fish; a value less than 0 if this fish is less than the Fish argument; and a value greater than 0 if this Fish is greater than the Fish argument.
	   Throws:
		java.lang.IllegalArgumentException - if another Fish is null
	 */
	@Override
	public int compareTo(final Fish fish) {
		
		if (fish == null) throw new IllegalArgumentException("Fish object can not be null");
		
		int compareValue = this.type.compareTo(fish.type); // returns 0 if equal, 1 if first is greater, 2 if second is greater
		
		// if types are equal compare weights
		if (compareValue == 0) { 
			compareValue = this.weight.compareTo(fish.weight);
		}
		
		return compareValue;
	}

	
}