package cscd210Methods;

import java.io.PrintStream;
import java.util.Scanner;

import cscd210Classes.Fish;

public class CSCD210Lab13Methods {

	
	/*
	 * fillArray(Scanner, int, int) - Static method in class cscd210Methods.CSCD210Lab13Methods
		The fillArray first builds an array of Fish references based on the argument total. 
		The fillArray method next reads a line from the file. The file is comma separated and is a valid file. The file contains type, weight. 
		Use a nextLine to read in the entire line and then separate that line using methods in the String class. 
		Once you have the type and weight separated build a Fish object and place the object into the array.
		Parameters:
			fin - Representing the Scanner object to an open file
			total - Representing how many items will be in the array
			linesPer - Representing the number of lines that make up a record
		Returns:
			Fish[] Representing a filled array of Fish objects
		Throws:
			java.lang.IllegalArgumentException - if fin is null
			java.lang.IllegalArgumentException - if total <=0
			java.lang.IllegalArgumentException - if linesPer is <=0
		NOTE:
			if you use methods in the String class to separate type from weight you will also need to use .trim() from the String class
	 */
	public static Fish[] fillArray(final Scanner fin, final int totalFish, final int linesPer) {
		
		String line = ""; // string for the line we are reading
		String currentType = ""; // string for the current fish type
		Double currentWeight = 0.0; // double that holds the current fish weight we are reading from file
		
		if (fin == null) throw new IllegalArgumentException("Scanner can not be null");
		if (totalFish <= 0) throw new IllegalArgumentException("Check input file, it can not be empty!");
		if (linesPer <= 0) throw new IllegalArgumentException("Lines per can not be less or equal to 0!");
		
		Fish[] myFish = new Fish[totalFish];
		
		for (int i = 0; i < totalFish; i++) {
			
			// lines per in this case is 1 so we are not using it to create a new loop
			line = fin.nextLine(); // line read looks like -> rainbow trout, 1.23
			currentType = line.split(",")[0].trim(); // getting string before , which represents type
			currentWeight = Double.parseDouble(line.split(",")[1].trim()); // getting string after , and casting it to double which represents weight
			
			myFish[i] = new Fish(currentType, currentWeight);
		}
		
		return myFish;
	}

	/*
	 * 
		printArray(Fish[], PrintStream) - Static method in class cscd210Methods.CSCD210Lab13Methods
			The printArray method uses the PrintStream object output to print out each 
			fish one fish per line to either the screen or the file depending on where output is an alias.
			Parameters:
				myFish - Representing the array of Fish
				output - Representing the PrintStream object to the screen or the file
			Throws:
				java.lang.IllegalArgumentException - if myFish is null or the length is <=0
				java.lang.IllegalArgumentException - if output is null
	 */
	public static void printArray(final Fish[] myFish, final PrintStream out) {

		if (out == null) 
			throw new IllegalArgumentException("PrintStream can not be null!");
		
		if (myFish == null || myFish.length <= 0) 
			throw new IllegalArgumentException("Fish array can not be null!");
		
		for (int i = 0; i < myFish.length; i++) {
			out.println(myFish[i].toString());
		}
	}

	
	/*
	 * readOutputFileName(Scanner) - Static method in class cscd210Methods.CSCD210Lab13Methods
		The readOutputFileName prompts the user of the name of an output file 
		and ensures a filename is entered.
		Parameters:
			kb - Representing the Scanner object to the keyboard
		Returns:
			String Representing the output filename
		Throws:
			java.lang.IllegalArgumentException - if kb is equal to null
		NOTE:
			The input buffer will be cleared by you at the end of the method
	 */
	public static String readOutputFileName(final Scanner kb) {
		
		if (kb == null) 
		      throw new IllegalArgumentException("Scanner can not be null"); // in case scanner is null
		
		String filename = ""; 
		
		do
	    {
	      System.out.print("Please enter the name of the output file ");
	      
	      filename = kb.nextLine();
	      
	    } while (filename.trim().isEmpty()); // in case string is empty, makes user add name for output file, trimming possible spaces
		
		return filename;
	}

	
	/*
	 * 
		readIndex(int, int, Scanner) - Static method in class cscd210Methods.CSCD210Lab13Methods
		The readIndex method prompts the user to enter a number that is 
		between the startIndex and endIndex inclusive.
		Parameters:
			startIndex - Representing the starting value
			endIndex - Representing the ending value
			kb - Representing the Scanner object to the keyboard
		Returns:
			int Representing a value between startIndex and endIndex inclusive
		Throws:
			java.lang.IllegalArgumentException - if startIndex is < 0
			java.lang.IllegalArgumentException - if endIndex is < 0 or < startIndex
			java.lang.IllegalArgumentException - if kb is null
		NOTE:
			The input buffer will be cleared by you at the end of the method
	 */
	public static int readIndex(final int startIndex,final int endIndex, final Scanner kb) {
		
		if (kb == null) 
		      throw new IllegalArgumentException("Scanner can not be null");

		if (startIndex < 0) 
		      throw new IllegalArgumentException("Start index can not be < 0");
		
		if (endIndex < 0 || endIndex < startIndex) 
		      throw new IllegalArgumentException("End index can not be < 0 or less then start index");
		
		int index = startIndex - 1; // setting index on one less so we can show the question right away
		
		while (index < startIndex || index > endIndex) 
		{
			System.out.println("Please enter fish index in order to compare, values between \n" + startIndex + " - " + endIndex);
			index = kb.nextInt();
		}
		
		kb.nextLine(); // clean the buffer
		return index;
	}

	
	/*
	 * menu(Scanner) - Static method in class cscd210Methods.CSCD210Lab13Methods
		The menu method prompts the user to enter a value between 1 and 4 inclusive.
		The menu method prompts the user for a menu choice, ensures the choice is within range and then returns that value. 
		Menu Choices
			1. prints the array to the screen
			2. prints the array to the file
			3. Asks the user to compare two fish for equality.
			4. Quit
		Parameters:
			kb - Representing the Scanner object to the keyboard
		Returns:
			int Representing a number between 1 and 4 inclusive
		Throws:
			java.lang.IllegalArgumentException - if kb is null
		NOTE:
			The input buffer will be cleared by you at the end of the method
	 */
	public static int menu(final Scanner kb) {

		if (kb == null) 
		      throw new IllegalArgumentException("Scanner can not be null"); // in case scanner is null
		
		int menuChoice = 0;
		
		while (menuChoice < 1 || menuChoice > 4) 
		{
			System.out.println("Menu Choices \n"
					+ "			1) Print the array to the screen \r\n" + 
					"			2) Print the array to the file \r\n" + 
					"			3) Compare two fish for equality \r\n" + 
					"			4) Quit ");
			
			menuChoice = kb.nextInt();
		}
		
		kb.nextLine(); // clean the buffer
		return menuChoice;
	}

}
