package cscd210Lab15;
import java.io.*;
import java.util.*;
import cscd210Utils.*;
import cscd210Classes.Book;
import cscd210Comparators.*;
import cscd210Methods.CSCD210Lab15Methods;


/**
 * The CSCD210Lab15 class for testing your program. You can't change this class in any fashion
 */
public class CSCD210Lab15
{
   /**
    * The main method for testing your code.  This method requires a command line parameter of the 
    * filename be passed from the command line. To understand how to pass command line parameters 
    * please see the writeup for lab 14
    *
    * @param args Representing the array of command line arguments
    * @throws Exception for quieting the compiler based on the Scanner and the File stuff
    * @throws IllegalArgumentException if args length is &lt; 1
    */
   public static void main(String [] args)throws Exception
   {
	  int choice;	   
      File inf = null;
      Book [] myBooks = null;
      PrintStream fout = null;
      String outFilename = null;
      Scanner kb = null, fin = null;
      
      if(args.length < 1)
    	  throw new IllegalArgumentException("You must pass a filename at the command line");
    	  
      
      inf = FileUtils.openInputFile(args[0]); 
      fin = new Scanner(inf);
      
      myBooks = CSCD210Lab15Methods.createAndFillArray(fin);
      fin.close();
      
      SortUtils.selectionSort(myBooks);
      
      kb = new Scanner(System.in);
      
      do
      {
         choice = CSCD210Lab15Methods.menu(kb);
         
         if(choice == 1)
            ArrayUtils.printArray(myBooks, System.out);
            
         else if(choice == 2)
         {
        	 outFilename = CSCD210Lab15Methods.readName(kb, "output");
             fout = new PrintStream(outFilename);
             ArrayUtils.printArray(myBooks, fout);
             fout.close();
         }// end choice 2
         
         else if(choice == 3)
         {
            Arrays.sort(myBooks, new AuthorsComparator());
            ArrayUtils.printArray(myBooks, System.out);
         }// end choice 3
         
         else if(choice == 4)
         {
            Arrays.sort(myBooks, new ISBNComparator());
            ArrayUtils.printArray(myBooks, System.out);
         }// end choice 4
         
         else if(choice == 5)
         {
            Arrays.sort(myBooks, new TitleComparator());
            ArrayUtils.printArray(myBooks, System.out);
            
         }// end choice 5
         
         else if(choice == 6)
         {
            Book toFind = CSCD210Lab15Methods.readBookToFind(kb);
            int location = SearchUtils.linearSearch(myBooks, toFind);  // calls the equals method
            if(location != -1)
               System.out.println("The book: " + myBooks[location] + " was found");
            
            else
               System.out.println("Book not found");
         }// end choice 6
         
      }while(choice != 7);
      
      System.out.println("Good Bye!");
      kb.close();
   }// end main
}// end class
