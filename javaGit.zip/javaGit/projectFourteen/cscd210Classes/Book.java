package cscd210Classes;

public class Book implements Comparable<Book> {

	private String[] authors; // The private array of authors for the book, each book has at least one author
	private String ISBN; // The private data member for the book ISBN
	private int pages; // The private data member for the book total pages
	private String title; // The private data member of the book title
	
	/*
	 * The EVC for the book. A deep copy of the array of authors must be made - meaning a new array for this.authors and a deep copy of each string will be performed.
	   Parameters:
		title - The book title
		ISBN - The book ISBN
		pages - The total number of pages
		authors - The array of authors -- a deep copy will be made
	   Throws:
		java.lang.IllegalArgumentException - if title or ISBN are null or empty or pages < 1 or authors is null or length < 1
	 */
	public Book(final String[] authors, final String iSBN, final int pages, final String title) {
		super();
		
		if (iSBN == null || iSBN.trim().isEmpty())
			throw new IllegalArgumentException("iSBN can not be empty!");
		
		if (title == null || title.trim().isEmpty())
			throw new IllegalArgumentException("title can not be empty!");
		
		if (pages < 1)
			throw new IllegalArgumentException("pages can not be < 1!");
		
		if (authors == null || authors.length < 1)
			throw new IllegalArgumentException("authors can not be empty!");
		
		this.authors = new String[authors.length];
		
		for (int i = 0; i < authors.length; i++) {
			this.authors[i] = new String(authors[i]);
		}
		
		this.ISBN = iSBN;
		this.pages = pages;
		this.title = title;
	}

	/*
	 * The generated hashCode from eclipse
	   Overrides:
		hashCode in class java.lang.Object
	   Returns:
		int Representing the hashCode
	 */
	@Override
	public int hashCode() {
		return this.title.hashCode() + this.authors.hashCode() + this.ISBN.hashCode();
	}
	
		/*
	 * The getAuthors that returns the book's array of authors
		Returns:
		String [] the authors
	 */
	public String[] getAuthors() {
		return authors;
	}

	/*
	 * The getISBN that returns the book's ISBN
		Returns:
		String the iSBN
	 */
	public String getISBN() {
		return ISBN;
	}

	/*
	 * The getPages that returns the book's number of pages
		Returns:
		int the pages
	 */
	public int getPages() {
		return pages;
	}

	/*
	 * The getTitle method that returns the book's title
		Returns:
		String the title
	 */
	public String getTitle() {
		return title;
	}

	/*
	 * The equals method that is generated from eclipse minus checking the array of authors
		Overrides:
			equals in class java.lang.Object
		Parameters:
			obj - Representing the object being passed in
		Returns:
			boolean true if the books title, ISBN and pages are the same false otherwise
	 */
	@Override
	public boolean equals(final Object obj) {
		
		if (obj instanceof Book) {
			if (this.title.equals(((Book)obj).getTitle()) && this.ISBN.equals(((Book)obj).getISBN()) && this.pages == (((Book)obj).getPages())) return true;
		}
		
		return false;
	}
	
	/*The compareTo method that first compares by title, then by pages and finally by the ISBN
		Specified by:
			compareTo in interface java.lang.Comparable<Book>
		Parameters:
			another - Because of the Generic it will be a Book
		Returns:
			int < 0 if this book is less than another book, > 0 if this book is greater than another book, and == 0 if the books are the same
		Throws:
			java.lang.IllegalArgumentException - if the passed in book is null
	*/
	@Override
	public int compareTo(final Book another) {

		if (another == null)
			throw new IllegalArgumentException("Book can not be null!");
		
		if (another.ISBN == null || another.ISBN.trim().isEmpty())
			throw new IllegalArgumentException("iSBN can not be empty!");
		
		if (another.title == null || another.title.trim().isEmpty())
			throw new IllegalArgumentException("title can not be empty!");
		
		if (another.pages < 1)
			throw new IllegalArgumentException("pages can not be < 1!");
		
		if (another.authors == null || another.authors.length < 1)
			throw new IllegalArgumentException("authors can not be empty!");
		
		int compareValue = this.title.compareTo(another.title); // returns 0 if equal, 1 if first is greater, 2 if second is greater
		
		// if titles are equal compare pages
		if (compareValue == 0) { 
			if (this.pages == another.pages) compareValue = 0;
			else if (this.pages > another.pages) compareValue = 1;
			else compareValue = -1;
		}
		
		if (compareValue == 0) {
			compareValue = this.ISBN.compareTo(another.ISBN);
		}
		
		return compareValue;
	}
	
	/*
	 * The toString that produces Title: this title carriage return 
		Author(s): the authors with the word and between each other carriage return 
		ISBN: this ISBN
		Overrides:
			toString in class java.lang.Object
		Returns:
			String representing the contents as described above
	 */
	@Override
	public String toString() {
		String book = "Title: " + this.title + "\n" + "Author(s) ";
		
		for (int i = 0; i < authors.length; i++) {
			if (i + 1 == authors.length) book += authors[i] + "\n";
			else book += authors[i] + " and ";
		}
		
		book += "ISBN: " + this.ISBN;
		
		return book;
	}

}
