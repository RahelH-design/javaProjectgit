package cscd210Methods;
import java.util.Scanner;
import cscd210Classes.Book;

public class CSCD210Lab15Methods
{
   /**
    * The menu method is provided.
    * @param kb Representing the Scanner object to the keyboard
    * @return int Representing the menu choice in range
    * @throws IllegalArgumentException if kb is null
    * @NOTE The input buffer is left clean
    */
   public static int menu(final Scanner kb)
   {

	   if (kb == null)
		   throw new IllegalArgumentException("Bad Params menu");

	   int choice;

	   do
	   {
		   System.out.println();
		   System.out.println("Please Choose from the following");
		   System.out.println("1)	Print all books to the screen");
		   System.out.println("2)	Print all books to a file that the user provides the name");
		   System.out.println("3)	Sort the array using the Comparator - AuthorsComparator and print to the screen");
		   System.out.println("4)	Sort the array using the Comparator - ISBNComparator and print to the screen");
		   System.out.println("5)	Sort the array using the Comparator - TitleComparator and print to the screen");
		   System.out.println("6)	Ask the user for a book title, isbn, number of pages " +
    							"and see if that book exists in the array by calling " +
    							"the equals method in the linear search method.");
		   System.out.println("7)	quit");
		   System.out.print("Choice --> ");

		   choice = Integer.parseInt(kb.nextLine());

	   } while(choice < 1 || choice > 7);

	   System.out.println();

	   return choice;

   }// end menu

   /*
    * The readBookToFind method prompts the user for the title of the book, the ISBN of the book, the total pages, the number of authors and then the name of each author. A book is then built and returned.
		Parameters:
			kb - Representing the Scanner object to the keyboard
		Returns:
			Book Representing a Book object from user provided information
		Throws:
			java.lang.IllegalArgumentException - if kb is null
		NOTE:
			You must leave the input buffer clean
    */
   public static Book readBookToFind(final Scanner kb) {
	   if (kb == null)
		   throw new IllegalArgumentException("Scanner can not be null!");
	   
	   String title, ISBN;
	   int pages;
	   String[] authors;
	   
	   System.out.println("Please enter the title ");
	   title = kb.nextLine();
	   
	   System.out.println("Please enter the ISBN ");
	   ISBN = kb.nextLine();
	   
	   System.out.println("Please enter the number of pages ");
	   pages = Integer.parseInt(kb.nextLine());
	   
	   System.out.println("Please enter the number of authors ");
	   authors = new String[Integer.parseInt(kb.nextLine())];
	   
	   for (int i = 0; i < authors.length; i++) {
		   System.out.println("Please enter the name of the author");
		   authors[i] = kb.nextLine();
	   }
	   
	   return new Book(authors, ISBN, pages, title);
   }
   
	public static Book[] createAndFillArray(final Scanner fin) {

		Book[] books = new Book[1];
		Book[] updatedBooks = books;
		
		while (fin.hasNext()) {
			
			updatedBooks = addBook(books, fin);
			books = new Book[updatedBooks.length];
			
			for (int i = 0; i < updatedBooks.length; i++) {
				books[i] = new Book(updatedBooks[i].getAuthors(), updatedBooks[i].getISBN(), updatedBooks[i].getPages(), updatedBooks[i].getTitle());
			}
		}
		
		return updatedBooks;
	}
	
	/*
	 * The readName method prompts the user for the name of the input or output file
		Parameters:
			kb - Representing the Scanner object to the keyboard
			type - Represeting the string input or the string output
		Returns:
			String Representing the name of the file
		Throws:
			java.lang.IllegalArgumentException - if kb or type are null or if type is empty
		NOTE:
			You must leave the input buffer clean
	 */
	public static String readName(final Scanner kb, final String type) {
		
		if (kb == null)
			   throw new IllegalArgumentException("Scanner can not be null!");
		
		if (type == null || type.trim().isEmpty())
			   throw new IllegalArgumentException("Type can not be empty!");
		   
		String filename = "";
		
		do
	    {
	      System.out.print("Please enter the name of the output file ");
	      filename = kb.nextLine();
	      
	    } while (filename.trim().isEmpty()); // in case string is empty, makes user add name for output file, trimming possible spaces
		
		return filename;
	}

	private static Book[] addBook(final Book[] array, final Scanner fin) {
		
		int i;
		
		if (fin == null)
			   throw new IllegalArgumentException("Scanner can not be null!");
		
		if (array == null)
			   throw new IllegalArgumentException("Array can not be null!");
		
		String line, title, ISBN;
		String[] authors, allAuthors;
		int pages;
		
		line = fin.nextLine();
		
		title = line.split(",")[0].trim();
		ISBN = line.split(",")[1].trim();
		pages = Integer.parseInt(line.split(",")[2].trim());
		
		authors = line.split(",");
		allAuthors = new String[authors.length - 3];
		int k = 0;
		
		for (int j = 3; j < authors.length; j++) {
			allAuthors[k] = authors[j].trim();
			k++;
		}
	   
		Book newBook = new Book(allAuthors, ISBN, pages, title);
		Book[] newArray;
		
		if (array[0] == null) {
			newArray = new Book[array.length];
			newArray[0] = newBook;
		} else {
			newArray = new Book[array.length + 1];
			
			for (i = 0; i < array.length; i++) {
				newArray[i] = new Book(array[i].getAuthors(), array[i].getISBN(), array[i].getPages(), array[i].getTitle());
			}
			
			newArray[i] = newBook;
		}
		
		return newArray;
	}
	
}// end class