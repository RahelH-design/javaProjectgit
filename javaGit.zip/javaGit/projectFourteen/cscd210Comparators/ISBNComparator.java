package cscd210Comparators;

import java.util.Comparator;

import cscd210Classes.Book;
import cscd210Utils.SortUtils;

public class ISBNComparator implements Comparator<Book> {

	/*
	 * The ISBNComparator class which provides a total ordering based solely on the ISBN of the book. This ensures via the generic that a book object is used
	The compare method that compares only based on the ISBN.
	Specified by:
		compare in interface java.util.Comparator<Book>
	Parameters:
		o1 - Representing the book that would be equal to this
		o2 - Representing the book that woulb be equal to another
	Returns:
		int A value < 0 if o1 ISBN is alphabetically before o2 ISBN, a value > 0 if o1 ISBN is alphabetically after o2 ISBN, a value == 0 if o1 ISBN is alphabetically the same as o2 ISBN,
	Throws:
		java.lang.IllegalArgumentException - if o1 or o2 are null
	*/
	@Override
	public int compare(final Book o1, final Book o2) {
		
		if (o1 == null || o2 == null) 
			throw new IllegalArgumentException("Books can not be null!");
		
		int compareValue = o1.getISBN().compareTo(o2.getISBN());		
		
		return compareValue; 
	}

}

