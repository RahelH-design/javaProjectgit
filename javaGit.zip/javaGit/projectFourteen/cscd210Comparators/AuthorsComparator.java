package cscd210Comparators;

import java.util.Comparator;
import cscd210Classes.Book;
import cscd210Utils.SortUtils;

/*
 * The AuthorsComparator class which provides a total ordering based solely on the Authors array of the book. 
 * This ensures via the generic that a book object is used
 */

public class AuthorsComparator implements Comparator<Book> {

	/*
	 *The compare method that compares only based on the authors array.
	 First the lengths are checked and if differnt the the result of subtracting o1 length from o2 length. If the lengths are the same the each o1 author is compared to each o2 author.
	Specified by:
		compare in interface java.util.Comparator<Book>
	Parameters:
		o1 - Representing the book that would be equal to this
		o2 - Representing the book that woulb be equal to another
	Returns:
		int A value < 0 if o1 length is less than o2 length, a value > 0 if o1 length is greater than o2 length, if the lengths are the same then each individual string is compared, and finally a value == 0 if o1 length is the same as o2 length and the authors are the same
	Throws:
		java.lang.IllegalArgumentException - if o1 or o2 are null
	NOTE:
		The author order does not matter so call the selectionSort on each array before you start comparing authors
	*/
	@Override
	public int compare(final Book o1, final Book o2) {
		
		if (o1 == null || o2 == null) 
			throw new IllegalArgumentException("Books can not be null!");
		
		int compareValue = 0;
		
		if (o1.getAuthors().length < o2.getAuthors().length) compareValue = -1;
		else if (o1.getAuthors().length > o2.getAuthors().length) compareValue = 1;
		
		// The author order does not matter so they need to be in the same order
		SortUtils.selectionSort(o1.getAuthors());
		SortUtils.selectionSort(o2.getAuthors());
		
		// if lengths are the same, iterate through arrays and compare authors
		if (compareValue == 0) {
			for (int i = 0; i < o1.getAuthors().length; i++) {
				compareValue = o1.getAuthors()[i].compareTo(o2.getAuthors()[i]);
				if (compareValue != 0) return compareValue; // in case authors are not the same, return comparedValue
			}
		}
		
		return compareValue; // in case all authors are the same, or if lengths of the array are not the same
	}

}

