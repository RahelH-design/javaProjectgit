package cscd210Utils;

import cscd210Classes.Book;

/*
 * The SearchUtils class performs basic array searching functions.
 */
public class SearchUtils <T> {

	/*
	 * The linearSearch functions walks the array element by element looking for the target. If the target is found the index of the first occurance of the target is returned. If the item is not in the array -1 is returned.
		Type Parameters:
	T - Representing the Generic type of the array
	Parameters:
		array - Representing the actual array
		target - Representing the item to be found
	Returns:
		int Representing the index of the first occurance of target or -1 if the item is not found
	Throws:
		java.lang.IllegalArgumentException - if the array is null, target is null, or the array length is < 1
	NOTE:
		Please notice the method is <T> void for the return type and T for the array type. T is replaced by the actual type when the code is compiled.
	 */
	public static <T> int linearSearch(final T[] myBooks, final T target) {
		
		if (myBooks == null || target == null || myBooks.length < 1)
			throw new IllegalArgumentException("Linear search params are not good!");
		
		int index = -1; // set index to -1
		
		for (int i = 0; i < myBooks.length; i++) {
			if (myBooks[i].equals(target)) return i;
		}
		
		
		return index;
	}

}
