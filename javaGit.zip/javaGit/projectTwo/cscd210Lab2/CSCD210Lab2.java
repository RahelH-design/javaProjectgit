package cscd210Lab2;
import java.util.Scanner;

public class CSCD210Lab2 {

	public static final int YEAR = 2019;
	public static void main(String[] args) {
		
		//Declare an object and initialize with predefined standard input object 
        Scanner kb= new Scanner(System.in);
        
        //empty string
        String name = null;
        
        //print the full name of the user
        System.out.print("please enter your full name: ");
        
        // string input read the keyboard
        name=kb.nextLine();
        
        
        //character input
        char letter= name.charAt(0);
        
        //print the value that gives the first letter of user name
        System.out.println("The first letter of your name is:"+" " + letter);
        
        //letter gets the last letter of user name by using length method
        letter =name.charAt(name.length()-1);
        
        //print the last letter of user name 
        System.out.println("The last letter of your name is:" +" "+ letter);
        
        //firstName gets the index numbers of the first name
        int firstName = name.indexOf(" ")+1;
        
        //lastName gets the last index of the last name
        int lastName = name.lastIndexOf(" ");
        
        //middleName gets to pull out the text inside the full name
        String middleName = name.substring(firstName, lastName);
        //String middleName =name.substring(name.indexOf(" "), name.lastIndexOf(" "));
        
        //print the middle name 
        System.out.println("your middle name: "+ middleName);
         
        //num gets integer values
        int num= name.hashCode();
        
        //print the hashcode  for your full name
        System.out.println("The hashCode of yourname is :" +" "+ num );
        
        //print  the hash code added to the year of 2019
        System.out.println("The hashCode of your name added to the year of 2019 is: " +" "+(num+YEAR));
      
        //display have a nice day
        System.out.println("Have a nice day!");
         
	}

}
