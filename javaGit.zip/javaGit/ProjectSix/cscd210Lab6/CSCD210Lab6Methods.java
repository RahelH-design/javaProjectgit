/**
 * 
 */
package cscd210Lab6;


import java.util.*;
/**
 * This is the class that will hold all the methods for lab 6. Every method that is
 * passed parameters will have the special modifier final on the parameter.  Examine 
 * the method header for the menu method to see an example of final on the method parameter(s)
 */
public class CSCD210Lab6Methods
{
		
   	
	/**
	 * An empty constructor you actually get this for free.  If I don't write this method
	 * it will still appear in the generate Javadoc
	 */
	public CSCD210Lab6Methods()
	{
		// Please ignore this method
	}
	
	
	/**
	 * This is the menu method.  It simple generates a menu and ensures the choice is entered 
	 * in the range of 1 to 3 inclusive <br/>
	 * <br/>
	 * NOTE This method ensures the input buffer is empty after the number has been read in
	 * <br/>
	 * @param kb Representing the Scanner object
	 * @return int Representing the user choice
	 * @throws IllegalArgumentException if the Scanner is null
	 */
	//a method header called readLength with one object parameter
	public static String readLength(final Scanner kb)
	{
		//expetion handling
		if(kb==null)
			throw new IllegalArgumentException("Scanner in menu is null");
		//prompt the user to enter the length
		System.out.println("Please enter the length from the center to the vertex 5.5");
		
		//read the input 
		String input= kb.nextLine();
		//return input
		return input;
	}
	
	//a method header name called display string input parameter
	public static double calcArea(final String input)
	{
		//exception handling
		if (input == null||input.isEmpty())
			throw new IllegalArgumentException("bad input");
		//the user input to double
		double length=Double.parseDouble(input);
		//calculate the area of the pentagon by calling calcArea method with the input length
		double result= CSCD210Lab6Methods.calcArea(length);
		//return result
		return result;
	}
	
	//a method header called display two parameter
	public static void displayResults(Double length,  double area)
	{
		System.out.println("The value of length was:  " +length);
		System.out.printf("The area of the pentagon is:%.3f\n" , CSCD210Lab6Methods.calcArea(length));
		
	}
	
	
  //a method header called readMaxLength with an object parameter
   public static double readMaxLength(final Scanner kb)
   {
	   if(kb==null)
			throw new IllegalArgumentException("Scanner in menu is null");
	   System.out.print("Please enter a number greater than 0 100: ");
	   double input= kb.nextDouble();
		return input;
	   
   }
 //a method header name called generateLength with two parameter
   public static double generateLength(double min, double max)
   {
	   //randome reference name with r
	   Random r = new Random();

	   //calculate the random number
	   double length = min + (max - min) * r.nextDouble();
	   
	   //return length
	   return length;
   }
   
 //method header name called calcArea with one paratmeter
 	public static double calcArea(final double input) 
 	{
        //the input converted to double 
		double length=Double.valueOf(input);
		
 	    //calculate the side of the pentagon
 		double side= 2*length*Math.sin(((Math.PI/5)));
 		
 		//calcualte the area of the pentagon
		 double area =(5*(Math.pow(side,2)))/(4*Math.tan(Math.PI/5));
 		
		//return the area of the calculated area
 		return area;
 		
	}
 	
 	//method header that has a return type int and one parameter
	public static int menu(final Scanner kb)
	{
		//exception handling
		if(kb == null)
			throw new IllegalArgumentException("Scanner in menu is null");
		
		//initialize choice
		int choice;
		
		//using do while loop
		do
		{
			//let the user know to choose one of the following choice
			System.out.println("Please choose from the following");
			//let the user to choose to enter a length
			System.out.println("1) Let the user enter a length");
			//let the user to choose generator a length
			System.out.println("2) Let the computer generate a length");
			//choice three to quit
			System.out.println("3) Quit");
			System.out.print("Choice --> ");
			
			//convert to integer
			choice = Integer.valueOf(kb.next());
			kb.nextLine();
			
		}while(choice < 1 || choice > 3);
		
		System.out.println();
		//return choice
		return choice;
	}//end method
	
	
}// end class
