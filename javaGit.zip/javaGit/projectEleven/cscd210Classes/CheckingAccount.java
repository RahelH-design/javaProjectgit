package cscd210Classes;

public class CheckingAccount {

	private int acctNum;
	private double bal;

	// constructor with one parameter
	public CheckingAccount(final int acctNum) {
		if(acctNum<100)
			throw new IllegalArgumentException("wrong input");
		this.acctNum = acctNum;
		this.bal = 100;// If only account number if given, initialize it with 100
	}

	// constructor with two parameter
	public CheckingAccount(final int acctNum, final double bal) {
		if (acctNum <= 0 || bal < 100)
			throw new IllegalArgumentException("wrong input");
		this.acctNum = acctNum;
		this.bal = bal;
	}

	public void deposit(final double amt) {
		if (amt <= 0)
			throw new IllegalArgumentException("wrong input");
		// the deposit method makes a deposit into the account
		this.setBalance(this.bal + amt);// Changed the code according to the instructions
	}

	public int getAcctNumber() {
		this.acctNum = acctNum;
		return acctNum;
	}

	public double getBalance() {
		return this.bal;
	}

	public int hashCode() {
		// Take the int as string and return its hashcode
		return String.valueOf(this.acctNum).hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CheckingAccount other = (CheckingAccount) obj;
		if (acctNum != other.acctNum)
			return false;
		if (Double.doubleToLongBits(bal) != Double.doubleToLongBits(other.bal))
			return false;
		return true;
	}

	public void setAccountNumber(final int acctNum) {
		if (acctNum <= 0)
			throw new IllegalArgumentException("wrong input");
		// setAccontNumber method sets the account number
		// to store in the account number field
		this.acctNum = acctNum;
	}

	private void setBalance(final double bal) {
		if (bal < 0)
			throw new IllegalArgumentException("wrong input");
		// setBalance method sets the account balance to store in the balance field
		this.bal = bal;
	}

	public String toString() {
		String result = "";
		result = "Account Number:" + " " + this.acctNum + "\nAccountNumber: $" + this.bal + "\n";
		return result;
	}

	public void withdrawal(final double amt) {
		if (amt <= 0)
			throw new IllegalArgumentException("wrong input");
		// the withdraw method withdraws an amount from the account
		// the amount to subtract from the balance field
		if(this.bal < amt) {
			return;// Amount is greater than balance, do nothing
		}
		double newBalance = bal - amt;
		bal = newBalance;

	}
}
