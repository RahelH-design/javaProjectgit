package cscd210Methods;

import java.util.Scanner;
import cscd210Classes.LargeInt;

/**
 * The methods that support CSCD210Lab16
 * NOTE: All parameters will be passed as final and you can't use Arrays
 */
public class CSCD210Lab16Methods
{  
	/**
	 * Don't write me I am free
	 */
	public CSCD210Lab16Methods() {}
	
	
   /**
    * The menu method is provided by me so I will not write a bunch
    * @param kb Representing the Scanner object to the keyboard
    * @return int Representing a menu choice in the range of 1 to 6 inclusive
    * @throws IllegalArgumentException if the Scanner object is null
    * NOTE: This method leaves the input buffer empty
    */
   public static int menu(final Scanner kb)
   {
	   if(kb == null)
		   throw new IllegalArgumentException("Bad Param menu");
	   
	   int choice;
	   
	   do
	   {
	   
		   System.out.println("Please choose from the following");
		   System.out.println("1) Print the array of LargeInts");
		   System.out.println("2) Prompt for two indexes and compare for equality");
		   System.out.println("3) Prompt for two indexes and add the LargeInts together");
		   System.out.println("4) Sort the array of LargeInts");
		   System.out.println("5) Sort the array based on the ReverseOrderComparator");
		   System.out.println("6) Quit");
		   System.out.print("Choice --> ");
		   
		   choice = Integer.parseInt(kb.nextLine());
		   
	   }while(choice < 1 || choice > 6);
	   
	   return choice;
   }// end menu

	/*
	 * The createAndFill method creates a LargeInt array of references of the size total that is passed in. The method then reads a string from the file and creates a LargeInt object and then assigns that object into the array.
		Parameters:
			total - The total number of LargeInt references in the array
			fin - The Scanner object to the file
		Returns:
			LargeInt [] Representing a filled array of LargeInt objects
		Throws:
			java.lang.IllegalArgumentException - if total is < 1 or if fin is null NOTE: The method will leave the file input buffer empty
	 */
	public static LargeInt[] createAndFill(int count, Scanner fin) {

		if (fin == null)
			throw new IllegalArgumentException("Scanner can not be null!");
		
		if (count < 1)
			throw new IllegalArgumentException("Count can not be < 1!");
		
		LargeInt[] array = new LargeInt[count];
		
		for (int i = 0; i < count; i++) {
			array[i] = new LargeInt(fin.nextLine());
		}
		
		return array;
	}
	
	/*
	 * The readNum asks the user for a number between 0 and the length of the array -1 inclusive. The method ensures the number entered is within range.
		Parameters:
			kb - Representing the Scanner object to the keyboard
			array - Representing the array of LargeInt objects
		Returns:
			int Representing an index of the array
		Throws:
			java.lang.IllegalArgumentException - if the Scanner object is null if the array is null or the array length is < 1 NOTE: This method must leave the input buffer empty
	 */
	public static int readNum(Scanner kb, LargeInt[] array) {
		
		if (kb == null || array == null || array.length < 1)
			throw new IllegalArgumentException("Scanner and array can not be null!");
		
		int readNumber = -1;
		
		while (readNumber < 0 || readNumber >= array.length) {
			System.out.println("Please select an index between 0 and " + (array.length - 1));
			readNumber = Integer.parseInt(kb.nextLine());
			
			if (readNumber < 0 || readNumber >= array.length) System.out.println("Index out of bound, please enter index again!");
		}
		
		return readNumber;
	}
   
   
 
}// end class