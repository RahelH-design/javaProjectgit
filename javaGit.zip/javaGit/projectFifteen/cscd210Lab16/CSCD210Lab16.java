package cscd210Lab16;

import java.io.*;
import java.util.*;
import cscd210Utils.ArrayUtils;
import cscd210Utils.FileUtils;
import cscd210Utils.SortUtils;
import cscd210Classes.LargeInt;
import cscd210Methods.CSCD210Lab16Methods;
import cscd210Comparators.ReverseOrderComparator;


/**
 * The class for the CSCD210Lab16 concerning an array of LargeInts
 * NOTE: All parameters will be passed as final and you can't use the Arrays class
 */
public class CSCD210Lab16
{
	/**
	 * The main method.  This controls program flow.  This method requires a command line parameter of the filename
	 * @param args The command line parameter that contains the filename
	 * @throws Exception For the Scanner object and to quiet the compiler.
	 */
	public static void main(final String [] args)throws Exception
	{
	   File inf = null;
	   LargeInt [] array = null;
	   int one, two, count, choice;
	   Scanner fin = null, kb = null;
	   
	   if(args.length < 1)
		   throw new IllegalArgumentException("You must pass a filename at the command line");
    	  
       inf = FileUtils.openInputFile(args[0]); 
	   fin = new Scanner(inf);
	   count = FileUtils.countRecords(fin, 1);
	   fin.close();
	   
	   fin = new Scanner(inf);
	   array = CSCD210Lab16Methods.createAndFill(count, fin);
	   fin.close();
	   
	   kb = new Scanner(System.in);
      
	   do
	   {
		   choice = CSCD210Lab16Methods.menu(kb);
	         
	       switch(choice)
	       {
	            case 1:  ArrayUtils.printArray(array, System.out);
	            		 System.out.println();
	                     break;
	
	            case 2: one = CSCD210Lab16Methods.readNum(kb, array);
	            		two = CSCD210Lab16Methods.readNum(kb, array);
	            		if(array[one].equals(array[two]))
	                        System.out.println("The LargeInts are equal");
	                    else
	                        System.out.println("The LargeInts are NOT equal");  
	            		System.out.println();
	                     break;
	                     
	            case 3:  one = CSCD210Lab16Methods.readNum(kb, array);
        				 two = CSCD210Lab16Methods.readNum(kb, array);
        				 LargeInt result = array[two].add(array[one]);
	                     System.out.printf("The results of %s added to %s is %s\n", array[two].getValue(), array[one].getValue(), result.getValue());
	                     System.out.println();
	                     break;  
	                     
	            case 4:  SortUtils.selectionSort(array);
	            		 ArrayUtils.printArray(array, System.out);
	            		 System.out.println();
	                     break;
	                     
	            case 5:	 Arrays.sort(array, new ReverseOrderComparator());
	            		 ArrayUtils.printArray(array, System.out);
	            		 System.out.println();
	            		 break;
	                     
	            default: System.out.println("The End!");
	                     
	         }// end switch
	       
	   }while(choice != 6);
	   
	   kb.close();
	   
	}// end main
   
}// end class