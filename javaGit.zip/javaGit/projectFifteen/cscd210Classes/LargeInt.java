package cscd210Classes;


public class LargeInt implements Comparable<LargeInt> {

	private int[] array; // The array to hold individual elements for the LargeInt
	
	/*
	 * The constructor that converts the String into individual integers in the array to ultimately produce a LargeInt object
	 	Parameters:
			number - The String representing the number
		Throws:
			java.lang.IllegalArgumentException - if number is null or empty
	 */
	public LargeInt(final String number) {
		
		if (number == null || number.trim().isEmpty())
			throw new IllegalArgumentException("String number can not be empty!");
		
		this.array = new int[number.length()];
		
		for (int i = 0; i < number.length(); i++) {
			this.array[i] = Character.getNumericValue(number.charAt(i));
		}
		
	}
	
	/*
	 * The toString builds a String representation of this array
		Overrides:
		to	String in class java.lang.Object
		Returns:
		Strin	g the String version of the LargeInt
	 */
	@Override
	public String toString() {
		String value = "";
		
		for (int i = 0; i < array.length; i++) {
			value += array[i];
		}
		
		return value;
	}
	
	@Override
	public boolean equals(final Object obj) {
		
		for (int i = 0; i < array.length; i++) {
			if (array[i] != ((LargeInt)(obj)).array[i]) return false;
		}
		
		return true;
	}
	
	/*
	 * The hashCode method calls the getValue method which returns a String and then calls the hashCode on that String
	 */
	@Override
	public int hashCode() {
		return this.getValue().hashCode();
	}
	
	/*
	 * The add method adds the two LargeInt objects together producing a new LargeInt. There is potential the new LargeInt may be one element larger than either this LargeInt or another LargeInt.
		Parameters:
			another - Representing the LargeInt to be added to this LargeInt
		Returns:
			LargeInt Representing the result of this LargeInt added to another LargeInt
		Throws:
			java.lang.IllegalArgumentException - if another is null
	 */
	public LargeInt add(final LargeInt another) {
		
		int myLength = this.array.length;
		int anotherLength = another.array.length;
		int smallerLength, biggerLength, overhead = 0;
		int[] newArray;
		
		
		// in case my length is longer, since addUp expects first array to have larger length
		if (myLength > anotherLength) {
			newArray = addUp(this.array, another.array);
		}
		// in case another.array is longer, since addUp expects first array to have larger length
		else {
			newArray = addUp(another.array, this.array);
		}
		
		LargeInt newLarge;
		
		// we made an array one larger than the bigger array length in case we need an extra space
		
		String newArrayString = "";
		int i = 0;
		
		if (newArray[0] == 0) i = 1; // now we check if we actually need it or not, if not we skip first 0
		
		for (; i < newArray.length; i++) {
			newArrayString += newArray[i];
		}
		
		return new LargeInt(newArrayString);
	}
	
	private int[] addUp (final int[] array1, final int[] array2) {
		
		int add = 0;
		int overhead = 0;
		int j = array1.length - 1;
		int[] newArray = new int[array1.length + 1];
		
		
		// going through the arrays from the last element
		for (int i = array2.length - 1; i >= 0; i--, j--) {
			add = array2[i] + array1[j]; // adding two numbers
			
			if (overhead != 0) add++; // in case there was overhead from previous calculation for example 9 + 3 is gonna be number 2 with overhead 1
			
			if (add > 9) { // if our number is larger than 9, add overhead and if subtract 10
				overhead = 1;
				add -= 10; // for example if we had 15, it should be 5 with overhead 1
			}
			else overhead = 0;
			
			newArray[j + 1] = add; // element is one more than the same element of array1, since its length is 1 longer
		}
		
		// if we still have overhead and keep having it, go through array and make changes, for example for 9999999 + 1111
		while (overhead != 0 && j >= 0) {
			add = array1[j];
			add++;
			
			if (add > 9) {
				overhead = 1;
				add -= 10;
			}
			else overhead = 0;
			
			newArray[j + 1] = add;
			
			j--;
		}
		
		// check if we need an extra number in the beginning of the array
		if (overhead != 0 && j == -1) newArray[j + 1] = 1;
		else if (j >= 0) {
			
			// go through the rest of bigger array and copy numbers that don't need changing
			for (; j >= 0; j--) newArray[j + 1] = array1[j];
		}
		return newArray;
	}
	
	/*
	 * The getValue returns the LargeInt value as a String
		Returns:
			String Representing the value of the LargeInt
	 */
	public String getValue() {
		String value = "";
		
		for (int i = 0; i < array.length; i++) {
			value += array[i];
		}
		
		return value;
	}

	/*
	 * The compareTo method first compares by length. If the lengths are the same it then compares by each individual element value;
		Specified by:
			compareTo in interface java.lang.Comparable<LargeInt>
		Parameters:
			another - Representing the other LargeInt to be compared
		Returns:
			int Representing order. < 0 if this LargeInt is numerically less than another LargeInt, > 0 if this LargeInt is numerically greater than another LargeInt, and equal to 0 if both LargeInts are the same
		Throws:
			java.lang.IllegalArgumentException - if another is null
	 */
	@Override
	public int compareTo(final LargeInt another) {
		
		int compareValue = 0;
		
		if (another == null)
			throw new IllegalArgumentException("Another can not be null!");

		if (this.array.length == another.array.length) compareValue = 0;
		else if (this.array.length > another.array.length) compareValue = 1;
		else compareValue = -1;
		
		if (compareValue == 0) {
			for (int i = 0; i < array.length; i++) {
				if (array[i] > another.array[i]) compareValue = 1;
				else if (array[i] < another.array[i]) compareValue = -1;
				
				if (compareValue != 0) return compareValue;
			}
		}
		
		return compareValue;
	}

}