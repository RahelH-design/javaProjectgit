package cscd210Comparators;
import java.util.Comparator;

import cscd210Classes.*;

/*
 * The class for the ReverseOrder comparison of two LargeInts NOTE: All parameters will be passed as final and you can't use the Arrays class
 */

public class ReverseOrderComparator implements Comparator<LargeInt> {

	/*
	 * The compare method first compares the length of the o2 LargeInt to the o1 LargeInt. If the lengths are the same, then the individual elements of the o2 string are compared to the individual elements of the o1 string.
		Specified by:
			compare in interface java.util.Comparator<LargeInt>
		Parameters:
			o1 - Representing the LargeInt that would be equivalent to this
			o2 - Representing the LargeInt that would be equivalent to another
		Returns:
			int Representing < 0 if the o2 string is lexically before the o1 string, > 0 if the o2 string is lexically after the o1 string, and equal to 0 if the o2 string is lexically the same as the o1 string
		Throws:
			java.lang.IllegalArgumentException - if either o1 or o2 are null
	 */
	@Override
	public int compare(final LargeInt o1, final LargeInt o2) {
		
		if (o1 == null || o2 == null)
			throw new IllegalArgumentException("LargeInt can not be null!");
		
		int compareValue = o2.compareTo(o1);
		
		return compareValue;
	}

}
