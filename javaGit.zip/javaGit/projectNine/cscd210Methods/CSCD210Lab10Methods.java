package cscd210Methods;

import java.io.File;
import java.io.PrintStream;
import java.util.Scanner;

import cscd210Utils.FileUtils;

public class CSCD210Lab10Methods {
	
	/*
	 * The readFilename method reads a string from the keyboard and ensure the string is not empty. 
	 * If the string is empty the user is reprompted.
		Parameters:
			kb - Representing the Scanner object to the keyboard
		Returns:
			String representing a non-empty string for the filename
		Throws:
			java.lang.IllegalArgumentException - if the Scanner object is null
	 * 
	 */
	public   static String readFilename(final Scanner kb) {
		
		if (kb == null) 
		      throw new IllegalArgumentException("Scanner can't be null"); // in case scanner is null
		
		String filename = ""; 
		
		do
	    {
	      System.out.print("Please enter the name of the output file ");
	      
	      filename = kb.nextLine();
	      
	    } while (filename.trim().isEmpty()); // in case string is empty, makes user add name for output file, trimming possible spaces
		
		return filename;
	}

	
	
	
	/* The encrypt method reads the original string from the file, reads the direction of shift 
	 * and the number to shift by calling the appropriate methods and 
	 * then encrypts the string and writes the results to the file. 
	 * If the direction to shift is lt then right is written to the file or vice versa
		Parameters:
			fin - Representing the Scanner object to the file
			fout - Representing the PrintStream object to the output file
			total - Representing the number of recoreds to encode
		Throws:
			java.lang.IllegalArgumentException - if fin or fout are null or if total < 1
	 * 
	 */
	public static void encrypt(final Scanner fin, final PrintStream fout, final int total) {
		
		if (fin == null) throw new IllegalArgumentException("Scanner can not be null");
		if (fout == null) throw new IllegalArgumentException("Print Stream can not be null");
		if (total < 1) throw new IllegalArgumentException("Total amount of lines in input file needs to be at least 3");
		
		// loop for encrypting
		
		String stringToEncrypt = ""; // string to be encrypted
		String direction = ""; // lt or rt
		String encryptedString = ""; // new encrypted string
		String phrase = "";
		
		int shiftAmount = 0; // shifting
		
		for (int i = 0; i < total; i++) {
			
			stringToEncrypt = fin.nextLine(); // call to function which reads original string
			
			direction = readDirection(fin); // call to function which translates direction
			
			shiftAmount = readAmountToShift(fin); // call to function which reads amount of shift used for encrypting
			
			encryptedString = encryptString(stringToEncrypt, shiftAmount, direction); // encription
			
			// An encrypted file will contain a single line for the direction of shift for decrypting, 
			// the number of elements to shift as an integer, and the encrypted string. 
			
			if (direction.equals("right")) direction = "left";
			else if (direction.equals("left")) direction = "right";
			
			phrase = direction + "" + Integer.toString(shiftAmount);
			display(phrase, encryptedString, fout);
		}
	}
	
	
	
	
	/*
	 * 
	 * The encryptString method encrypts the string in the format of direction number to shift the string

		For example STU left 1 would be written as right1TUV 
		Parameters:
			origString - Representing the original String that is not encrypted
			amount - Representing the amount to shift
			direction - Representing the direction to shift as right or left
		Returns:
			 encrypted string in the format of direction number to shift the string
		Throws:
			java.lang.IllegalArgumentException - if origString or direction are null or empty or if amount is <= 0
	 * 
	 * 
	 */
	private static String encryptString(final String origString, final int amount, final String direction) {
		
		if (origString == null || origString.trim().isEmpty() || direction == null || direction.trim().isEmpty() || amount <= 0)
			throw new IllegalArgumentException("Please check validity of your input file!");
		
		String encryptedString = "";
		int shiftedChar = 0;
		int currentChar = 0;
		int base = 0; // base is either 65 if upper case or 97 for lower case
		int newAmount = amount;
		
		if (direction.equals("right")) newAmount *= -1; // if direction is right make amount negative, code stays the same
		
		// going through string and shifting depending if it is capital or small letter
		
		for (int i = 0; i < origString.length(); i++) {
			
			currentChar = (int)(origString.charAt(i)); // int value of current char
			
			if (Character.isAlphabetic(origString.charAt(i))) { // change just if it is a letter
				
				if (Character.isUpperCase(origString.charAt(i))) base = 65; // upper case, 65 is A in ASCII
				else base = 97; // lower case, 97 is a in ASCII
				
				int position = (currentChar + newAmount - base) % 26; // for example for char a, right and amount 2, this will be 97 + (-2) + 97 which is -2 module 26 gives us -2
				
				if (position < 0) shiftedChar = 26 + position + base; // in case module is negative, we should retract it from the 26 so we can get a position in alphabet and then add base to get position in ascii
				else shiftedChar = (currentChar + newAmount - base) % 26 + base; 
				
				encryptedString = encryptedString.concat(Character.toString((char)shiftedChar));
			}
			else encryptedString = encryptedString.concat(Character.toString(origString.charAt(i)));
		}
		
		return encryptedString;
	}

	
	
	
	/*
	 * The menu method prompts the user for a menu choice, 
	 * ensures the choice is within range and then returns that value. 
	 * The menu method must leave the keyboard input buffer clean. 
	 * The menu choices are: 
			1) Encrypt a file writing the results to a different file 
			2) Decrypt a file writing the results to a different file 
			3) Decrypt a file writing the results to the screen 
			4) Quit 
		Parameters:
			kb - Representing the Scanner to the keyboard
		Returns:
			int Representing the menu choice in range
		Throws:
			java.lang.IllegalArgumentException - if the Scanner object is null
	 * 
	 */
	public static int menu(final Scanner kb) {
		
		int menuChoice = 0;
		
		while (menuChoice < 1 || menuChoice > 4) 
		{
			System.out.println("Choose one of the options \n"
					+ "			1) Encrypt a file writing the results to a different file \r\n" + 
					"			2) Decrypt a file writing the results to a different file \r\n" + 
					"			3) Decrypt a file writing the results to the screen \r\n" + 
					"			4) Quit ");
			
			menuChoice = kb.nextInt();
		}
		
		kb.nextLine(); // clean the buffer
		return menuChoice;
	}
	
	

	/*
		The decrypt method takes an encrypted string in the format of direction number string and 
		it decrypts the string creating 3 separate lines.
		If the direction is right then lt is written to the file or the screen or vice versa. 
		This method calls the appropriate private methods.
		
		Parameters:
			fin - Representing the Scanner object to the input file
			fout - Representing the PrintStream object to the file or the screen
		Throws:
			java.lang.IllegalArgumentException - if fin or fout are null
		
	*/
	public static void decrypt(final Scanner fin, final PrintStream fout) {

		if (fin == null || fout == null) throw new IllegalArgumentException("Scanner and PrintStream can not be null!");
		
		while (fin.hasNext())
	    {
			String encryptedString = fin.nextLine();
			
			String direction = determineDirection(encryptedString);
			int amount = amountShifted(encryptedString);
			String decryptedString = decryptString(encryptedString, amount, direction);
			
			if (direction == "right") direction = "lt";
			else if (direction == "left") direction = "rt";
			
			display(direction, amount, decryptedString, fout);
	    }
	}
	
	
	
	
	/* The decryptString method uses the encryptedString, the amount of shift and the direction to decrypt the string
	 * 
	 * Parameters:
			encryptedString - Representing the encrypted String
			amount - Representing the shift amount
			direction - Representing the direction to decrypt
	   Returns:
			The decrypted string
	   Throws:
			java.lang.IllegalArgumentException - if the string is null or empty
	 * 
	 */
	private static String decryptString(final String encryptedString, final int amount, final String direction) {

		String encryptedStringSubstring = encryptedString; // substring of encrypted String we got
		String decryptedString = "";
		
		if (encryptedString == null || encryptedString.isEmpty()) 
			throw new IllegalArgumentException("Please check validity of file for decrypting!");
			
		
		if (encryptedString.startsWith("right")) encryptedStringSubstring = encryptedString.substring(5); //remove right from string
		else if (encryptedString.startsWith("left")) encryptedStringSubstring = encryptedString.substring(4); //remove left from string
		
		int i;
		
		for (i = 0; i < encryptedStringSubstring.length(); i++) { // remove number from the string
			if (!Character.isDigit(encryptedStringSubstring.charAt(i))) break;
		}
		
		encryptedStringSubstring = encryptedStringSubstring.substring(i);
			
		decryptedString = encryptString(encryptedStringSubstring, amount, direction); // the same function can be used as for encrypting, just in different direction
		
		return decryptedString;
	}
	
	
	

	/* The readAmountShifted determines the amount the string was shifted
	 * Parameters:
			encryptedString - Represented the encrypted string
			Returns: int - Representing the amount the string was shift
	   Throws:
			java.lang.IllegalArgumentException - if the string is null or empty 
	*/
	private static int amountShifted(final String encryptedString) {
		
		String encryptedStringSubstring = encryptedString; // substring of encrypted String we got
		
		if (encryptedString == null || encryptedString.isEmpty()) 
			throw new IllegalArgumentException("Please check validity of file for decrypting!");
		
		if (encryptedString.startsWith("right")) encryptedStringSubstring = encryptedString.substring(5); //remove right from string
		else if (encryptedString.startsWith("left")) encryptedStringSubstring = encryptedString.substring(4); //remove left from string
		
		String amount = "";
		
		for (int i = 0; i < encryptedStringSubstring.length(); i++) {
			
			if (Character.isDigit(encryptedStringSubstring.charAt(i))) amount = amount.concat(Character.toString(encryptedStringSubstring.charAt(i)));
			else break;
			
		}
		
		return Integer.parseInt(amount);
	}
	
	
	
	
	/* This method determines the encrypted direction from the encrypted String
	 * 
	 * Parameters:
			encryptedString - Representing the direction needed to decrypt
	   Returns:
			The direction as lt or rt
	   Throws:
			java.lang.IllegalArgumentException - if the string is null or empty
	 * 
	 * 
	 */
	private static String determineDirection(final String encryptedString) {
		
		if (encryptedString == null || encryptedString.isEmpty()) 
			throw new IllegalArgumentException("Please check validity of file for decrypting!");
		
		if (encryptedString.startsWith("right")) return "right";
		else if (encryptedString.startsWith("left")) return "left";
		else throw new IllegalArgumentException("Please check validity of file for decrypting!");
	}
	
	
	
	
	/*
	 * 
	 * The readAmountToShift reads the amount of shift from the file
		Parameters:
				fin - Representing an open Scanner object
		Returns:
			int Representing the number of elements to shift
		Throws:
			java.lang.IllegalArgumentException - if the Scanner object is null
	 */
	private static int readAmountToShift(final Scanner fin) {
		
		if (fin == null) throw new IllegalArgumentException("Scanner can not be null");
		
		// return next int for the amount of shifting
		int amount = Integer.parseInt(fin.nextLine());
		fin.hasNextLine(); // so it moves to new line for reading further
		
		return amount;
	}

	
	
	
	
	/*
	 * The readDirection reads either rt or lt from the file and converts rt to right and lt to left
		Parameters:
			fin - Representing an open Scanner object
		Returns:
			String representing the direction to shift either as right or left
		Throws:
			java.lang.IllegalArgumentException - if the Scanner object is null
	 * 
	 */
	private static String readDirection(final Scanner fin) {
		
		if (fin == null) throw new IllegalArgumentException("Scanner can not be null");
		
		String direction = fin.nextLine();
		
		if (direction.equals("rt")) direction = "right";
		else if (direction.equals("lt")) direction = "left";
		else throw new IllegalArgumentException("Direction for scanning must be lt or rt");
		
		return direction;
	}
	
	
	
	
	/* The display function writes the decrypted string to the file in 3 lines.
	 * This output should match the original unencrpytped string.
		Parameters:
			dir - Representing the direction as rt or lt
			number - Representing the number for the shift
			str - Representing the decrypted string
			fout - Representing the PrintStream object to the file or to the screen
		Throws:
			java.lang.IllegalArgumentException - if the dir or str are null or empty or if fout is null
	 * 
	 * 
	 */
	private static void	display(final String direction, final int amount, final String decryptedString, final PrintStream fout) {
		if (direction == null || direction.isEmpty() || fout == null || decryptedString == null || decryptedString.isEmpty()) 
			throw new IllegalArgumentException("Please check your decrypt file!");
		
		fout.println(decryptedString);
		fout.println(direction);
		fout.println(amount);
		
	}
	
	
	
	
	/*
	 * The display function displays the encrypted string either to the file. 
	 * The phase represents the shift direction and the shift number the String str represents the encrypted string. 
	 * This output will appear on a single line
		Parameters:
			phrase - Representing the direction and the number
			str - Representing the encrytped string
			fout - Representing the PrintStream to the file
		Throws:
			java.lang.IllegalArgumentException - if the phrase or str are null or empty or if fout is null
	 * 
	 * 
	 * 
	 */
	private static void display(final String phrase, final String str, final PrintStream fout) {
		
		if (str == null || str.isEmpty() || fout == null) 
			throw new IllegalArgumentException("Please check your decrypt file!");
		
		fout.print(phrase);
		fout.print(str);
		fout.println();
	}
	
	
	
	
	/*
	 * 
	 * 
	 * The readString reads the either the un-encrypted string or the encrypted string
		Parameters:
			fin - Representing an open Scanner object
		Returns:
			String Representing either the encrypted string or decrypted string
		Throws:
			java.lang.IllegalArgumentException - if the Scanner object is null
	 */
	private static String readString(final Scanner fin) {
		// An encrypted file will contain a single line for the direction of shift for decrypting, 
		// the number of elements to shift as an integer, and the encrypted string.
		
		if (fin == null) throw new IllegalArgumentException("Scanner can not be null");
		
		String readString = "";
		
		return readString;
	}
}
