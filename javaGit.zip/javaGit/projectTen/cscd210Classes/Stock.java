package cscd210Classes;

public class Stock {
     
	//declare the instance variable
	private String companyName;
	private double currentPrice;
	private double purchasePrice;
	private String ticker;
	
	//creating default constructor 
	public Stock()
	{
		this.companyName="DOW Jones Industrial Average";
		this.purchasePrice=0.0;
		this.currentPrice=12;
		this.ticker="DOW";
	}
	//explicit value constructor
	public Stock(final String ticker, final String companyName, final double currentPrice)
    {
		if(companyName==null)
			throw new IllegalArgumentException ("wrong input");
		if(currentPrice<=0)
			throw new IllegalArgumentException ("wrong input");
    	this.ticker=ticker;
    	this.companyName=companyName;
    	this.currentPrice=currentPrice;
    	this.purchasePrice=10.0;
    }
	  //explicit value constructor
   public Stock(final String companyName,final double currentPrice,final String ticker)
    {
	   if(companyName==null)
			throw new IllegalArgumentException ("wrong input");
		if(currentPrice<=0)
			throw new IllegalArgumentException ("wrong input");
    	this.ticker=ticker;
    	this.companyName=companyName;
    	this.currentPrice=currentPrice;
    	this.purchasePrice=5.0;
    	
    }
  
   
    
    //creating method
  
@Override
    public String toString()
    {
    	String result=" ";
    	result= this.companyName+" "+ "-"+" "+this.ticker+"\n"+ "Purchase Price:"+ " "+this.purchasePrice +" \n"+"Current Price:"+" "+ this.currentPrice;
    	return result;
    }
}
