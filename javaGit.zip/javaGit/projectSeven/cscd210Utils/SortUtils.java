
package cscd210Utils;
import java.util.Scanner;

public class SortUtils
{
	//public  SortUtils();
	public static void selectionSort(final int[] myArray)
	{
		
/*The selectionSort method sorts the array of integers in ascending order 
	NOTE: This method is provided by me 
	Parameters:
	myArray - Representing an array of integers
	Throws:
	java.lang.IllegalArgumentException - if myArray is null
	java.lang.IllegalArgumentException - if the length of myArray is less than or equal to zero
*/
		

		if(myArray==null || myArray.length<=0)
		{
			throw new IllegalArgumentException("bad input");
		}

		// One by one remove the unsorted subarray
		for (int i = 0; i < myArray.length-1; i++)
		{
			// Find the minimum element in unsorted array
			int minimum_index = i;
			//// accessing the elements of the specified array 
			for (int j = i+1; j < myArray.length; j++)
				if (myArray[j] < myArray[minimum_index])
					minimum_index = j;

			// Swap the found minimum element with the first
			// element
			int temp = myArray[minimum_index];
			myArray[minimum_index] = myArray[i];
			myArray[i] = temp;
		}
	}
}