
package cscd210Utils;
import java.util.Scanner;

public class ArrayUtils {
    //start the method
	public static int[] createAndFillArray(final int num, java.util.Scanner kb)
	{
		
/*The createAndFillArray method creates the integer array of size num and then fills the array by asking the user to enter an integer.
Parameters:
num - Representing the size of the array to create
kb - Representing the Scanner object to the keyboard
Returns:
int[] Representing created array that if filled with integers
Throws:
java.lang.IllegalArgumentException - if num is less than or equal to 0
java.lang.IllegalArgumentException - if kb is null
		 * *
		 */
		//assign reference variable input number for int array
		int[] inputNumber=new int[num];
		
		//prompt the user to enter some numbers
		System.out.println("Enter numbers for array please: ");
		for (int i=0;i<num;i++)
		{
			//read the user input
			inputNumber[i]=kb.nextInt();
			//if it is less exception handle 
			if(inputNumber[i]<=0)
			{
				throw new IllegalArgumentException("bad input");
				
			}
		}
		//return the value input number
		return inputNumber;
	}
	
	public static int[] addNum(final int[] myArray, java.util.Scanner kb)
	{
		/*
		 *The addNum method makes a new array that is one more 
		 *in length the old array which is passed in. 
		 *The method then copies the values from the old array (index by index)
		 * and places the values in the new array. Finally the user is prompted 
		 * to enter a value and that value is placed within the new array in the last index.
Parameters:
myArray - Representing the old array of integers that will be copied.
kb - Representing the Scanner object to the keyboard
Returns:
int[] Representing the new array with a value added
Throws:
java.lang.IllegalArgumentException - if kb is null
java.lang.IllegalArgumentException - if myArray is null
java.lang.IllegalArgumentException - if the length of myArray is less than or equal to zero
		 */
		// *The addNum method makes a new array that is one more
		// allocating memory to array
		int[] newArray=new int[myArray.length + 1];
		
		//initialize the last value zero
		int lastValue = 0;

		//if kb is null
		if (kb == null)
			throw new IllegalArgumentException("bad input");
        //if myArray is null and if the length of myArray is less than or equal to zero
		if (myArray == null || myArray.length <= 0)
			throw new IllegalArgumentException("bad input");
        
	     // accessing the elements of the specified array 
		for (int i=0; i<myArray.length; i++)
		{
			// allocate myArray.length +1 Account objects, and store their pointers in the array
			newArray[i]=myArray[i];
		}
        
		//prompt the user to enter
		System.out.print("Enter last number for new array please: ");
		//read the value from the user that enter
		lastValue = kb.nextInt();

		newArray[myArray.length] = lastValue;
        
		//return to new array
		return newArray;
	}

	public static int[] deleteValue(final int[] myArray, java.util.Scanner kb)
	{
/*The deleteValue method first prompts the user to enter a value that should be deleted.
Next the method searches through the array to determine if that value was in the array.
If the value is not in the array, a message "Value NOT found" is displayed and 
the old array is returned.
If the value is found a new array is made with the length being one less than 
the old array being passed in.
Next the values are copied over except the value that will be deleted.
Finally the new array is returned
Parameters:
myArray - Representing the old array of integers
kb - Representing the Scanner object to the keyboard
Returns:
int[] Representing the new/old array
Throws:
java.lang.IllegalArgumentException - if kb is null
java.lang.IllegalArgumentException - if myArray is null
java.lang.IllegalArgumentException - if the length of myArray is less than or equal to zero
		 * 
		 */
		//initialize delete value
		int deleteValue = 0;
		boolean found = false;
		int i = 0;

		System.out.print("Please enter a value to delete: ");
		deleteValue=kb.nextInt();
        
		//if we found the value (found = true) then we need to return 
		//the newarray with the value deleted
		////if we did not find it (found == false) then we return the old array
		while ((false == found) && (i < myArray.length))
		{
			
			if (deleteValue == myArray[i])
			{
				found = true;
			}
			++i;
		}
       
		if (found)
		{
			int[] newArray = new int[myArray.length - 1];
			int j = 0;

			for (i = 0; i < myArray.length; i++)
			{
				if (deleteValue != myArray[i])
				{
					newArray[j] = myArray[i];
					++j;
				}
			}

			return newArray;
		}
		else
		{
			System.out.println("Value NOT found");
			return myArray;
		}
	}

	public static int[] deleteValueByIndex(int[] myArray,
            java.util.Scanner kb)
/*The deleteValueByIndex method first prompts the user to enter an index and ensures 
 * the index is between 0 and the length of the old array minus 1.
A new array is made with the length being one less than the old array being passed in.
Next the values are copied over except the value at the index that will be deleted.
Finally the new array is returned
Parameters:
myArray - Representing the old array of integers
kb - Representing the Scanner object to the keyboard
Returns:
int[] Representing the new array with that is one less in length than the old array passed in
Throws:
java.lang.IllegalArgumentException - if kb is null
java.lang.IllegalArgumentException - if myArray is null
java.lang.IllegalArgumentException - if the length of myArray is less than or equal to zero
	 * 
	 * 
	 */
	{   //initialize deleteValueByIndex assigned zero
		int deleteValueByIndex = 0;
		//initialize i assigned zero
		int i = 0;
       //prompt the user to enter the value index to delete
		System.out.print("Please enter a value index to delete: ");
		//read the value
		deleteValueByIndex=kb.nextInt();
        ////The deleteValueByIndex method makes a new array that is reducing one more
		// allocating memory to array
		int[] newArray = new int[myArray.length - 1];
		//inititalize j assinged to zero
		int j = 0;
        //// accessing the elements of the specified array 
		for (i = 0; i < myArray.length; i++)
		{
			if (deleteValueByIndex != i)
			{
				newArray[j] = myArray[i];
				++j;
			}
		}

		return newArray;//return new array
	}
	
	public static void printArray(final int[] myArray)
	{
/*The printArray method prints the array in the following fashion
[value, value, value, ..., value]
Parameters:
myArray - Representing the array of integers to be printed
Throws:
java.lang.IllegalArgumentException - if myArray is null
java.lang.IllegalArgumentException - if the length of myArray is less than or equal to zero
* * 
		 * 
		 */
		//print the array with square bracket
		System.out.print("[");
		// accessing the elements of the specified array 
		for (int i = 0; i < myArray.length; i++)
		{
			System.out.print(myArray[i]);
			if (myArray.length != i+1)
			{
				//print it out with comma
				System.out.print(", ");
			}
		}
		//print the close bracket for the array
		System.out.println("]");
	}
	
}