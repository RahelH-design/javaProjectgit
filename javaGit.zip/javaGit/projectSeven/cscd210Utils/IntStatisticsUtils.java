package cscd210Utils;
import java.util.Scanner;

import static cscd210Utils.SortUtils.selectionSort;

public class IntStatisticsUtils {

	public static double computeMean(final int[] myArray)
	{
/*The computeMean method computes the mean of the array by summing 
 * the values in the array and then dividing by the number of elements in the array 
NOTE: Integer arithmetic happens so ensure you cast so double arithmetic happens 
Parameters:
myArray - Representing the array of integers
Returns:
double Representing the mean of the integers in the array
Throws:
java.lang.IllegalArgumentException - if myArray is null
java.lang.IllegalArgumentException - if the length of myArray is less than or equal to zero
		 * 
		 */
		if(myArray==null)
			throw new IllegalArgumentException("bad input");
        //inititalize total to zero
		int total=0;
		// accessing the elements of the specified array 
		for(int i=0; i<myArray.length;i++)
		{
			total+=myArray[i];
		}
		//return the mean value
		return (double)total/myArray.length;
	}

public static void printResults(final java.lang.String type, double result)
{
/*The printResults methods prints the results of the statistical 
 * calculation String type is once again a literal string that will be printed to the screen
Parameters:
type - Representing a literal String to what is being printed
result - Representing the result of the statistical calculation
	 * 
	 */
	
	//prtint the result
	System.out.println(type + " = " + result);
}

public static double computeMedian(final int[] myArray)
{
/*The computeMedian method computes the median value of the array
First the array is sorted by calling the SortUtils method

The calculation for a median is different for an array of even length versus an array of an odd length.
An array with an odd length:
1. Find the index of the middle element of the array.
2. Compute middle index with length divided by 2.
3. The median would be the value at this array index.

An array with an even length:
1. There will be the two middle values.
2. Compute index #1 with array length divided by 2.
3. Compute index #2 with index #1 - 1
4. Get the values stored at index #1 and index #2
5. The median is the two values added together and divided by 2.

NOTE: Integer arithmetic happens so ensure you cast so double arithmetic happens 
Parameters:
myArray - Representing the array of integers
Returns:
double Representing the median of the integers in the array
Throws:
java.lang.IllegalArgumentException - if myArray is null
java.lang.IllegalArgumentException - if the length of myArray is less than or equal to zero
* 
*/
	//calling the selectionSort(myArray)
	cscd210Utils.SortUtils.selectionSort(myArray);
	//declare the median
    double median;
	int sizeOfElement=myArray.length;
	if(myArray==null && myArray.length<=0)
		throw new IllegalArgumentException("bad input");
	//if it is odd then the median will be the middle number
	//if it is even, then the median add together and divide by two
	if(sizeOfElement%2==0)
	{
		int sumOfMiddleNumber=myArray[sizeOfElement/2]+myArray[sizeOfElement/2-1];
		median=(double)sumOfMiddleNumber/2;
	}
	else
	{
		median=(double)myArray[myArray.length/2];
	}
	return median;//return the median
}
public static double computeMidpoint(final int[] myArray)
{
/*The midpoint is the mean of the smallest and largest values in your array.
1. Sort your array in ascending order by calling SortUtils
2. Retrieve the values from the beginning and end of the array
3. The midpoint is those two values added together and divided by 2

NOTE: Integer arithmetic happens so ensure you cast so double arithmetic happens 
Parameters:
myArray - Representing the array of integers
Returns:
double Representing the midpoint of the integers in the array
Throws:
java.lang.IllegalArgumentException - if myArray is null
java.lang.IllegalArgumentException - if the length of myArray is less than or equal to zero
 * 
*/
	cscd210Utils.SortUtils.selectionSort(myArray);
	if(myArray==null || myArray.length<=0)
		throw new IllegalArgumentException("bad input");
		
	return ((double)myArray[0]+myArray[myArray.length-1])/2;
}

public static double computeStdDev(final int[] myArray)
{
/*The standard deviation shows how much variation from the average exists.
1. Compute the mean of the array.
2. Create a new array of deviations by subtracting the mean from each member from the original array.
3. Square each member of the deviations array.
4. Total those squared deviations.
5. Divide by one less than the original array length.
6. The standard deviation is the square root of that number.

NOTE: Integer arithmetic happens so ensure you cast so double arithmetic happens 
Parameters:
myArray - Representing the array of integers
Returns:
double Representing the mean of the integers in the array
Throws:
java.lang.IllegalArgumentException - if myArray is null
java.lang.IllegalArgumentException - if the length of myArray is less than or equal to zero
* 
*/
	double total = 0;

	if(myArray==null || myArray.length<=0)
		throw new IllegalArgumentException("bad input");
    //calling the compute mean method and assign it to mean
	double mean=computeMean(myArray);
   //// allocating memory to array
	double[] newArray = new double[myArray.length];
    // // accessing the elements of the specified array
	for (int i = 0; i < myArray.length; ++i)
	{
		newArray[i] = myArray[i] - mean;
		newArray[i] *= newArray[i];
		total += newArray[i];
	}
   //the calculated value return the stdev
    return Math.sqrt(total/(myArray.length-1));
}

}

