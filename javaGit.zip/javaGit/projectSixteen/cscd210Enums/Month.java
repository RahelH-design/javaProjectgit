package cscd210Enums;
import java.io.Serializable;

public enum Month implements Comparable<Month>, Serializable {
	
	JAN("january", 31), 
	FEB("february", 28),
	MAR("march", 31),
	APR("april", 30),
	MAY("may", 31),
	JUN("june", 30),
	JUL("july", 31),
	AUG("august", 31),
	SEP("september", 30),
	OCT("october", 31),
	NOV("november", 30),
	DEC("december", 31);
	private int days; // Private data member representing the number of days in the month
	private String month; // Private data member representing the String version of the month name
	
	Month(final String month, final int days) 
	    {
			this.days = days;
			this.month = month;
		}
	
	
	public String toString()
	{
	/*Returns the month name with the first letter capitalized. For example JAN("january", 31) will return January
	Overrides:
	toString in class java.lang.Enum<Month>
	Returns:
	String Representing the month name with the first character being a capital*/
		
		return month.substring(0, 1).toUpperCase() + month.substring(1);
	}
	public int getDays()
	{
	/*getDays returns the number of days in the month
	Returns:
	int Representing the number of days in the month*/
		return days;
	}

}
