package cscd210Methods;

import java.util.Iterator;
import java.util.Scanner;
import cscd210Enums.Month;

/**
 * The methods that support CSCD210Lab16
 * NOTE: All parameters will be passed as final and you can't use Arrays
 */
public class CSCD210Lab17Methods
{  	
   /**
    Standard menu method with the following options
		1) Print the array to the screen
		2) Sort the array by Natural Order
		3) Sort the array by Total Order based on days
		4) Quit
		
	The method must ensure a value in range is entered
	Parameters:
		kb - Representing a Scanner object to the keyboard
	Returns:
		int Representing a menu choice in range
	Throws:
		java.lang.IllegalArgumentException - if the Scanner object is null
	NOTE:
		You must ensure the input buffer is empty at the end of the method
    */
   public static int menu(final Scanner kb)
   {
	   if (kb == null)
		   throw new IllegalArgumentException("Bad Param menu");
	   
	   int choice;
	   
	   do
	   {
		   System.out.println("Please choose from the following");
		   System.out.println("1) Print the array to the screen");
		   System.out.println("2) Sort the array by Natural Order");
		   System.out.println("3) Sort the array by Total Order based on days");
		   System.out.println("4) Quit");
		   System.out.print("Choice --> ");
		   
		   choice = Integer.parseInt(kb.nextLine());
		   
	   } while (choice < 1 || choice > 4);
	   
	   return choice;
   }// end menu

	/*
	 * The fill array method is passed a Scanner object to a file and the total number of lines in the file. Each line is a record. The method builds an array of Month enumerated types.
		Parameters:
			fin - Representing a Scanner object to an open file
			total - Representing the number of records in the file
		Returns:
			Month [] Representing a filled array of months
		Throws:
			java.lang.IllegalArgumentException - if fin is null or if total is < 1
	 */
	public static Month[] fillArray(final Scanner fin, final int total) {

		if (fin == null)
			throw new IllegalArgumentException("Scanner can not be null!");
		
		if (total < 1)
			throw new IllegalArgumentException("Count can not be < 1!");
		
		Month[] array = new Month[total];
		
		for (int i = 0; i < total; i++) {
			array[i] = getMonth(fin.nextLine());
		}
		
		return array;
	}
	
	
	/*
	 * The getMonth method receives a String and returns the appropriate enumerated data type. This method must convert the String to an enumerated type in the most generic way possible. This means no hard coding
		Parameters:
			str - Representing the string to convert
		Returns:
			Month Representing the converted String into an enumerated type
		Throws:
			java.lang.IllegalArgumentException - if the string is null or empty or it doesn't match an enumerated data type
	 */
	public static Month getMonth(final String str) {

		if (str == null || str.trim().isEmpty())
			throw new IllegalArgumentException("String can not be null");
		
		for (Month m : Month.values()) {
			if (str.toLowerCase().startsWith(m.name().toLowerCase())) return Month.valueOf(m.name());
		}
		
		return null;
	}
	
	
	/*
	 * The print array method prints the contents of the arrray comma separated. 
		For example January, February, March
		Parameters:
			array - Representing an array of Months
		Throws:
			java.lang.IllegalArgumentException - if array is null or the length is < 1
	 */
	public static void printArray(final Month[] array) {
		if (array == null || array.length < 1) 
			throw new IllegalArgumentException("Array needs to be filled!");
	
		String arrayString = "";
		int i = 0;
		
		for (Month m : array) {
			i++;
			arrayString += m.toString();
			
			if (i < array.length) arrayString += ", "; // add , for every except last one
		}
		
		System.out.println(arrayString);
	}

}// end class