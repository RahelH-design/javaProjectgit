package cscd210Comparators;
import java.util.Comparator;

import cscd210Enums.*;

/*
 * This class is meant to provide for a total ordering of Months. The class ensures via the generic that a Month is used
 */

public class MonthDayOrdinalComparator implements Comparator<Month> {

	
	/*
		The compare method first compares the two months by days. If the number of days are then same then the two months are compared based on the ordinal value
		Specified by:
			compare in interface java.util.Comparator<Month>
		Parameters:
			m1 - Representing the first month to be compared
			m2 - Representing the second month to be compared
		Returns:
			int Representing a value < 0, > 0 or == 0 based on the days in the month then the ordinal value of the months
		Throws:
			java.lang.IllegalArgumentException - if either month is null
	 */
	
	@Override
	public int compare(final Month m1, final Month m2) {
		
		if (m1 == null || m2 == null)
			throw new IllegalArgumentException("Months to compare can not be null");
		
		int compareValue = 0;
		
		// first comparing lengths
		if (m1.getDays() > m2.getDays()) compareValue = 1;
		else if (m1.getDays() < m2.getDays()) compareValue = -1;
		
		// comparing ordinals -> their positions in enum 
		if (compareValue == 0) {
			if (m1.ordinal() > m2.ordinal()) compareValue = 1;
			else compareValue = -1;
		}
		
		return compareValue;
	}

	

}